import { useEffect, useRef, useState, useCallback } from "react";
import {
  Heart, Coins, Timer, Flame, Star, Pause, Play, Volume2, VolumeX,
  Home, RotateCcw, ArrowRight, ShoppingBag, Trophy, Flag, ChevronLeft,
  ChevronRight, Zap, Sparkles, Skull, Gamepad2,
} from "lucide-react";
import { GameEngine, VIEW_W, VIEW_H, type HudState, type LevelResult } from "../game/engine";
import { buildLevel } from "../game/levels";
import type { Skin } from "../game/skins";
import { audio } from "../game/audio";
import SkinSprite from "./SkinSprite";

interface Props {
  levelIndex: number;
  skin: Skin;
  sound: boolean;
  bankCoins: number;
  onToggleSound: () => void;
  addCoins: (n: number) => void;
  completeLevel: (index: number, score: number) => void;
  goMenu: () => void;
  goShop: () => void;
  goLevels: () => void;
  playLevel: (i: number) => void;
}

function press(code: string, down: boolean) {
  window.dispatchEvent(new KeyboardEvent(down ? "keydown" : "keyup", { code }));
}

export default function GameCanvas(props: Props) {
  const { levelIndex, skin, sound } = props;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [ready, setReady] = useState(true);
  const [paused, setPaused] = useState(false);
  const [complete, setComplete] = useState<LevelResult | null>(null);
  const [gameOver, setGameOver] = useState<LevelResult | null>(null);
  const [runId, setRunId] = useState(0);
  const levelInfo = buildLevel(levelIndex);
  const isTouch = typeof window !== "undefined" && ("ontouchstart" in window || navigator.maxTouchPoints > 0);

  const bankedRef = useRef(false);

  useEffect(() => {
    bankedRef.current = false;
    setComplete(null);
    setGameOver(null);
    setReady(true);
    setPaused(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    audio.unlock();
    const engine = new GameEngine(canvas, {
      levelIndex,
      skin,
      lives: 3,
      sound,
      onHud: (h) => setHud(h),
      onLevelComplete: (r) => {
        if (!bankedRef.current) {
          bankedRef.current = true;
          props.addCoins(r.coins);
          props.completeLevel(levelIndex, r.score);
        }
        setComplete(r);
      },
      onGameOver: (r) => {
        if (!bankedRef.current) {
          bankedRef.current = true;
          props.addCoins(r.coins);
        }
        setGameOver(r);
      },
    });
    engineRef.current = engine;
    engine.setPaused(true);
    engine.start();
    const t = window.setTimeout(() => {
      setReady(false);
      engine.setPaused(false);
    }, 2000);
    return () => {
      window.clearTimeout(t);
      engine.destroy();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelIndex, runId]);

  // keep skin/sound in sync
  useEffect(() => {
    engineRef.current?.setSound(sound);
  }, [sound]);

  const togglePause = useCallback(() => {
    if (complete || gameOver || ready) return;
    setPaused((p) => {
      const np = !p;
      engineRef.current?.setPaused(np);
      return np;
    });
  }, [complete, gameOver, ready]);

  // pause on Esc / P
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyP") togglePause();
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [togglePause]);

  const stars = complete
    ? 1 + (complete.coins >= 8 ? 1 : 0) + (complete.timeLeft >= levelInfo.timeLimit * 0.35 ? 1 : 0)
    : 0;

  const rageColor = !hud ? "#22b14c" : hud.rage01 < 0.33 ? "#22b14c" : hud.rage01 < 0.66 ? "#ffd700" : "#e52521";

  return (
    <div className="flex min-h-screen flex-col items-center bg-[#070a1a] px-2 py-3 sm:px-4">
      {/* HUD BAR */}
      <div className="pixel-panel w-full max-w-5xl rounded-lg bg-[#101736] px-3 py-2 sm:px-4">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2">
          <div className="flex items-center gap-3">
            <div>
              <div className="font-pixel text-[8px] text-cyan-300">SCORE</div>
              <div className="font-pixel text-xs text-white sm:text-sm">{String(hud?.score ?? 0).padStart(6, "0")}</div>
            </div>
            <div>
              <div className="font-pixel flex items-center gap-1 text-[8px] text-yellow-300">
                <Coins size={10} /> COINS
              </div>
              <div className="font-pixel text-xs text-yellow-300 sm:text-sm">
                ×{String(hud?.coins ?? 0).padStart(2, "0")}
                <span className="ml-2 text-[9px] text-yellow-600">BANK {props.bankCoins}</span>
              </div>
            </div>
            <div className="hidden sm:block">
              <div className="font-pixel text-[8px] text-green-300">WORLD</div>
              <div className="font-pixel text-xs text-white sm:text-sm">1-{levelIndex + 1}</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-center">
              <div className={`font-pixel flex items-center gap-1 text-[8px] ${(hud?.timeLeft ?? 99) <= 30 ? "animate-blink-hard text-red-400" : "text-orange-300"}`}>
                <Timer size={10} /> TIME
              </div>
              <div className={`font-pixel text-xs sm:text-sm ${(hud?.timeLeft ?? 99) <= 30 ? "text-red-400" : "text-white"}`}>
                {hud?.timeLeft ?? levelInfo.timeLimit}
              </div>
            </div>
            <div className="text-center">
              <div className="font-pixel flex items-center gap-1 text-[8px] text-pink-300">
                <Heart size={10} /> LIVES
              </div>
              <div className="flex justify-center gap-0.5 pt-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Heart key={i} size={12} className={i < (hud?.lives ?? 3) ? "fill-red-500 text-red-500" : "text-slate-700"} />
                ))}
              </div>
            </div>
            {/* rage */}
            <div className="hidden w-32 md:block">
              <div className="font-pixel flex items-center gap-1 text-[8px]" style={{ color: rageColor }}>
                <Flame size={10} /> RAGE ×{(hud?.difficulty ?? 1).toFixed(1)}
              </div>
              <div className="mt-1 h-2.5 overflow-hidden rounded-sm border border-black bg-black/60">
                <div
                  className="h-full transition-all duration-300"
                  style={{ width: `${(hud?.rage01 ?? 0) * 100}%`, background: `linear-gradient(90deg,#22b14c,#ffd700,#e52521)` }}
                />
              </div>
            </div>
            {/* power */}
            <div className="hidden text-center sm:block">
              <div className="font-pixel text-[8px] text-purple-300">POWER</div>
              <div className={`font-pixel mt-0.5 inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[9px] ${hud?.power === "fire" ? "bg-orange-500 text-white" : hud?.power === "big" ? "bg-blue-500 text-white" : "bg-slate-700 text-slate-300"}`}>
                {hud?.star && <Sparkles size={10} />}
                {hud?.power === "fire" ? <Zap size={10} /> : null}
                {hud?.star ? "STAR" : (hud?.power ?? "small").toUpperCase()}
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <button onClick={props.onToggleSound} className="pixel-btn rounded bg-slate-700 p-2 text-white" title="Sound">
                {sound ? <Volume2 size={14} /> : <VolumeX size={14} />}
              </button>
              <button onClick={togglePause} className="pixel-btn rounded bg-slate-700 p-2 text-white" title="Pause (P)">
                {paused ? <Play size={14} /> : <Pause size={14} />}
              </button>
              <button onClick={props.goMenu} className="pixel-btn rounded bg-slate-700 p-2 text-white" title="Quit">
                <Home size={14} />
              </button>
            </div>
          </div>
        </div>
        {/* progress */}
        <div className="mt-2 flex items-center gap-2">
          <Flag size={12} className="shrink-0 text-green-400" />
          <div className="relative h-2 flex-1 overflow-hidden rounded-full bg-black/60">
            <div className="absolute inset-y-0 left-0 bg-gradient-to-r from-green-500 via-yellow-400 to-red-500" style={{ width: `${(hud?.progress ?? 0) * 100}%` }} />
            {hud?.checkpoint && <div className="absolute inset-y-0 w-1 bg-white/70" style={{ left: "50%" }} />}
          </div>
          <span className="font-pixel text-[8px] text-slate-400">{Math.round((hud?.progress ?? 0) * 100)}%</span>
        </div>
        {/* mobile rage meter */}
        <div className="mt-1.5 flex items-center gap-2 md:hidden">
          <Flame size={12} className="shrink-0" style={{ color: rageColor }} />
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-black/60">
            <div
              className="h-full"
              style={{ width: `${(hud?.rage01 ?? 0) * 100}%`, background: `linear-gradient(90deg,#22b14c,#ffd700,#e52521)` }}
            />
          </div>
          <span className="font-pixel text-[8px]" style={{ color: rageColor }}>RAGE ×{(hud?.difficulty ?? 1).toFixed(1)}</span>
        </div>
      </div>

      {/* GAME VIEWPORT */}
      <div className="relative mt-2 w-full max-w-5xl select-none">
        <div className="pixel-panel crt relative overflow-hidden rounded-lg bg-black" style={{ touchAction: "none" }}>
          <canvas
            ref={canvasRef}
            width={VIEW_W}
            height={VIEW_H}
            className="pixelated block aspect-video w-full"
          />

          {/* toast */}
          {hud?.toast && !ready && !complete && !gameOver && (
            <div className="pointer-events-none absolute left-1/2 top-3 z-20 -translate-x-1/2">
              <div className="font-pixel animate-bounce-soft whitespace-nowrap rounded border-2 border-yellow-300 bg-black/80 px-3 py-2 text-[10px] text-yellow-300 sm:text-xs">
                {hud.toast}
              </div>
            </div>
          )}

          {/* GET READY */}
          {ready && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/70">
              <div className="font-pixel text-[10px] text-cyan-300 sm:text-xs">{levelInfo.sub}</div>
              <div className="font-pixel text-stroke mt-2 text-xl text-yellow-300 sm:text-3xl">{levelInfo.name}</div>
              <div className="mt-4 flex items-center gap-4">
                <SkinSprite skin={skin} size={52} />
                <div className="text-left">
                  <div className="font-pixel text-[10px] text-white">× {3}</div>
                  <div className="font-retro mt-1 text-xl leading-none text-slate-300">{skin.name}</div>
                </div>
              </div>
              <div className="font-pixel animate-blink-hard mt-5 text-xs text-white sm:text-sm">GET READY!</div>
              <div className="font-retro mt-2 text-lg text-slate-400">Enemies get faster over time — keep moving!</div>
            </div>
          )}

          {/* PAUSE */}
          {paused && !complete && !gameOver && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-black/70 p-4">
              <div className="font-pixel text-stroke text-2xl text-white sm:text-3xl">PAUSED</div>
              <div className="mt-6 flex flex-wrap justify-center gap-2">
                <button onClick={togglePause} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-green-500 px-4 py-3 text-[10px] text-white">
                  <Play size={14} /> RESUME
                </button>
                <button onClick={() => setRunId((r) => r + 1)} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-blue-500 px-4 py-3 text-[10px] text-white">
                  <RotateCcw size={14} /> RESTART
                </button>
                <button onClick={props.goLevels} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-purple-500 px-4 py-3 text-[10px] text-white">
                  <Gamepad2 size={14} /> LEVELS
                </button>
                <button onClick={props.goMenu} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-slate-600 px-4 py-3 text-[10px] text-white">
                  <Home size={14} /> QUIT
                </button>
              </div>
              <div className="font-retro mt-4 hidden text-xl text-slate-400 sm:block">Arrows / WASD move • Space jump • Shift run &amp; fire • P pause</div>
            </div>
          )}

          {/* LEVEL COMPLETE */}
          {complete && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/70 p-3">
              <div className="pixel-panel w-full max-w-md rounded-lg bg-[#101736] p-5 text-center">
                <div className="font-pixel text-[10px] text-green-300">COURSE CLEAR!</div>
                <div className="mt-2 flex justify-center gap-1">
                  {[0, 1, 2].map((i) => (
                    <Star key={i} size={30} className={i < stars ? "fill-yellow-300 text-yellow-300" : "text-slate-700"} />
                  ))}
                </div>
                <div className="font-pixel mt-3 text-lg text-white sm:text-xl">{levelInfo.name}</div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel text-[8px] text-cyan-300">SCORE</div>
                    <div className="font-pixel mt-1 text-xs text-white">{complete.score}</div>
                  </div>
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel flex items-center justify-center gap-1 text-[8px] text-yellow-300"><Coins size={10} /> COINS</div>
                    <div className="font-pixel mt-1 text-xs text-yellow-300">+{complete.coins}</div>
                  </div>
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel flex items-center justify-center gap-1 text-[8px] text-orange-300"><Timer size={10} /> TIME</div>
                    <div className="font-pixel mt-1 text-xs text-white">{complete.timeLeft}s</div>
                  </div>
                </div>
                <div className="font-retro mt-2 text-xl text-yellow-200">+{complete.coins} coins banked! Spend them on skins.</div>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  {levelIndex < 4 ? (
                    <button onClick={() => props.playLevel(levelIndex + 1)} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-green-500 px-4 py-3 text-[10px] text-white">
                      NEXT <ArrowRight size={14} />
                    </button>
                  ) : (
                    <button onClick={props.goLevels} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-green-500 px-4 py-3 text-[10px] text-white">
                      <Trophy size={14} /> YOU WIN!
                    </button>
                  )}
                  <button onClick={() => setRunId((r) => r + 1)} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-blue-500 px-4 py-3 text-[10px] text-white">
                    <RotateCcw size={14} /> REPLAY
                  </button>
                  <button onClick={props.goShop} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-yellow-500 px-4 py-3 text-[10px] text-black">
                    <ShoppingBag size={14} /> SHOP
                  </button>
                  <button onClick={props.goMenu} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-slate-600 px-4 py-3 text-[10px] text-white">
                    <Home size={14} /> MENU
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* GAME OVER */}
          {gameOver && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 p-3">
              <div className="pixel-panel w-full max-w-md rounded-lg bg-[#2b0d12] p-5 text-center">
                <Skull size={40} className="mx-auto text-red-400" />
                <div className="font-pixel text-stroke mt-2 text-2xl text-red-500">GAME OVER</div>
                <div className="font-retro mt-1 text-xl text-slate-300">The rage consumed you... but coins are kept!</div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel text-[8px] text-cyan-300">SCORE</div>
                    <div className="font-pixel mt-1 text-xs text-white">{gameOver.score}</div>
                  </div>
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel text-[8px] text-yellow-300">COINS</div>
                    <div className="font-pixel mt-1 text-xs text-yellow-300">+{gameOver.coins}</div>
                  </div>
                  <div className="rounded border-2 border-black bg-black/50 p-2">
                    <div className="font-pixel text-[8px] text-orange-300">TIME</div>
                    <div className="font-pixel mt-1 text-xs text-white">{gameOver.elapsed}s</div>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  <button onClick={() => setRunId((r) => r + 1)} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-green-500 px-4 py-3 text-[10px] text-white">
                    <RotateCcw size={14} /> TRY AGAIN
                  </button>
                  <button onClick={props.goShop} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-yellow-500 px-4 py-3 text-[10px] text-black">
                    <ShoppingBag size={14} /> SHOP
                  </button>
                  <button onClick={props.goMenu} className="pixel-btn font-pixel flex items-center gap-2 rounded bg-slate-600 px-4 py-3 text-[10px] text-white">
                    <Home size={14} /> MENU
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* TOUCH CONTROLS */}
        {isTouch && !complete && !gameOver && (
          <div
            className="mt-2 flex items-center justify-between gap-2 sm:hidden"
            onContextMenu={(e) => e.preventDefault()}
          >
            <div className="flex gap-2">
              <button
                className="pixel-btn rounded-lg bg-slate-800/90 p-4 text-white"
                style={{ touchAction: "none" }}
                onPointerDown={(e) => { e.preventDefault(); press("ArrowLeft", true); }}
                onPointerUp={() => press("ArrowLeft", false)}
                onPointerLeave={() => press("ArrowLeft", false)}
                onPointerCancel={() => press("ArrowLeft", false)}
              >
                <ChevronLeft size={28} />
              </button>
              <button
                className="pixel-btn rounded-lg bg-slate-800/90 p-4 text-white"
                style={{ touchAction: "none" }}
                onPointerDown={(e) => { e.preventDefault(); press("ArrowRight", true); }}
                onPointerUp={() => press("ArrowRight", false)}
                onPointerLeave={() => press("ArrowRight", false)}
                onPointerCancel={() => press("ArrowRight", false)}
              >
                <ChevronRight size={28} />
              </button>
            </div>
            <div className="flex gap-2">
              <button
                className="pixel-btn rounded-full bg-orange-600/90 p-4 text-white"
                style={{ touchAction: "none" }}
                onPointerDown={(e) => { e.preventDefault(); press("ShiftLeft", true); }}
                onPointerUp={() => press("ShiftLeft", false)}
                onPointerLeave={() => press("ShiftLeft", false)}
                onPointerCancel={() => press("ShiftLeft", false)}
              >
                <span className="font-pixel text-xs">B</span>
              </button>
              <button
                className="pixel-btn rounded-full bg-red-600/90 p-5 text-white"
                style={{ touchAction: "none" }}
                onPointerDown={(e) => { e.preventDefault(); press("Space", true); }}
                onPointerUp={() => press("Space", false)}
                onPointerLeave={() => press("Space", false)}
                onPointerCancel={() => press("Space", false)}
              >
                <span className="font-pixel text-xs">A</span>
              </button>
            </div>
          </div>
        )}

        {/* desktop hint */}
        <div className="font-retro mt-1 hidden items-center justify-center gap-4 text-lg text-slate-500 sm:flex">
          <span>← → move</span>
          <span>SPACE jump</span>
          <span>SHIFT run + fire</span>
          <span>P pause</span>
        </div>
      </div>
    </div>
  );
}
