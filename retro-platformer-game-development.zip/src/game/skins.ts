export interface SkinColors {
  hat: string;
  hatDark: string;
  shirt: string;
  overalls: string;
  overallsDark: string;
  skin: string;
  shoes: string;
  glove: string;
}

export interface Skin {
  id: string;
  name: string;
  cost: number;
  tagline: string;
  colors: SkinColors;
  glow?: string;
}

export const SKINS: Skin[] = [
  {
    id: "classic",
    name: "Classic Red",
    cost: 0,
    tagline: "The legendary plumber",
    colors: {
      hat: "#e52521",
      hatDark: "#8f1414",
      shirt: "#e52521",
      overalls: "#2b5cff",
      overallsDark: "#1a3596",
      skin: "#ffcf9e",
      shoes: "#5b2d0e",
      glove: "#ffffff",
    },
  },
  {
    id: "ranger",
    name: "Green Ranger",
    cost: 60,
    tagline: "Player two energy",
    colors: {
      hat: "#22b14c",
      hatDark: "#0f6b2c",
      shirt: "#22b14c",
      overalls: "#20305c",
      overallsDark: "#111a38",
      skin: "#ffcf9e",
      shoes: "#4a2a10",
      glove: "#ffffff",
    },
  },
  {
    id: "frost",
    name: "Frost Bite",
    cost: 140,
    tagline: "Ice cold finisher",
    colors: {
      hat: "#4dd8ff",
      hatDark: "#1d7fa8",
      shirt: "#4dd8ff",
      overalls: "#e8f7ff",
      overallsDark: "#9cc4d8",
      skin: "#ffd9b3",
      shoes: "#1d3a5c",
      glove: "#ffffff",
    },
  },
  {
    id: "bubblegum",
    name: "Bubblegum",
    cost: 180,
    tagline: "Sweet but deadly",
    colors: {
      hat: "#ff5da2",
      hatDark: "#a3135b",
      shirt: "#ff5da2",
      overalls: "#7b2bff",
      overallsDark: "#4a16a3",
      skin: "#ffe0c2",
      shoes: "#5c1040",
      glove: "#fff0f7",
    },
  },
  {
    id: "inferno",
    name: "Inferno",
    cost: 260,
    tagline: "Leaves fire behind",
    colors: {
      hat: "#ff7b00",
      hatDark: "#a34a00",
      shirt: "#ff2e00",
      overalls: "#2b2b2b",
      overallsDark: "#0d0d0d",
      skin: "#ffcf9e",
      shoes: "#3d0a00",
      glove: "#ffe28a",
    },
    glow: "#ff7b00",
  },
  {
    id: "shadow",
    name: "Shadow Ninja",
    cost: 340,
    tagline: "Moves unseen",
    colors: {
      hat: "#23232e",
      hatDark: "#0c0c12",
      shirt: "#3a3a4d",
      overalls: "#12121a",
      overallsDark: "#000000",
      skin: "#d9b48c",
      shoes: "#000000",
      glove: "#8f8fa3",
    },
    glow: "#7b2bff",
  },
  {
    id: "gold",
    name: "Golden King",
    cost: 500,
    tagline: "Drip of royalty",
    colors: {
      hat: "#ffd700",
      hatDark: "#9c7a00",
      shirt: "#ffd700",
      overalls: "#8f1414",
      overallsDark: "#5c0d0d",
      skin: "#ffcf9e",
      shoes: "#5b2d0e",
      glove: "#fff7cc",
    },
    glow: "#ffd700",
  },
  {
    id: "galaxy",
    name: "Galaxy",
    cost: 750,
    tagline: "From another world",
    colors: {
      hat: "#7b2bff",
      hatDark: "#3d0f8f",
      shirt: "#00e5ff",
      overalls: "#1b0f3d",
      overallsDark: "#0b0620",
      skin: "#ffcfa8",
      shoes: "#12082b",
      glove: "#c9f6ff",
    },
    glow: "#00e5ff",
  },
];

export function getSkin(id: string): Skin {
  return SKINS.find((s) => s.id === id) ?? SKINS[0];
}
