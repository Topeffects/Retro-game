export const TILE = 36;
export const ROWS = 15;
export const GROUND_ROW = 13;

// Tile ids
export const T = {
  EMPTY: 0,
  GROUND: 1,
  BRICK: 2,
  QCOIN: 3,
  QMUSH: 4,
  USED: 5,
  METAL: 6,
  PIPE_TL: 7,
  PIPE_TR: 8,
  PIPE_BL: 9,
  PIPE_BR: 10,
  FLAG: 11,
  FLAG_TOP: 12,
  SPIKE: 13,
  STONE: 14,
  WOOD: 15,
  STAR_BRICK: 18,
  ONEUP_BRICK: 19,
} as const;

export type EnemyType = "walker" | "turtle" | "flyer" | "spiky";

export interface CoinSpawn {
  tx: number;
  ty: number;
}
export interface EnemySpawn {
  type: EnemyType;
  tx: number;
  ty: number; // tile row where feet stand (for flyers, center row)
}

export interface Theme {
  id: string;
  label: string;
  skyDayTop: string;
  skyDayMid: string;
  skyDayBot: string;
  skyNightTop: string;
  skyNightMid: string;
  skyNightBot: string;
  hillFar: string;
  hillNear: string;
  cloud: string;
  bush: string;
  groundTop: string;
  groundBase: string;
  groundDark: string;
  grass: string;
  underground?: boolean;
}

export interface LevelData {
  index: number;
  name: string;
  sub: string;
  width: number;
  height: number;
  tiles: number[][];
  coins: CoinSpawn[];
  enemies: EnemySpawn[];
  playerStart: { tx: number; ty: number };
  flagCol: number;
  castleCol: number;
  checkpointCol: number;
  timeLimit: number;
  theme: Theme;
  baseDifficulty: number;
}

export const THEMES: Theme[] = [
  {
    id: "meadow",
    label: "Sunny Meadows",
    skyDayTop: "#3fa9f5",
    skyDayMid: "#7cc9ff",
    skyDayBot: "#c9ecff",
    skyNightTop: "#0b1035",
    skyNightMid: "#1c2a5e",
    skyNightBot: "#3b4a8f",
    hillFar: "#7ddb6b",
    hillNear: "#3fae4a",
    cloud: "#ffffff",
    bush: "#2f9e44",
    groundTop: "#e8a33d",
    groundBase: "#b25a1e",
    groundDark: "#6e3408",
    grass: "#3fd44f",
  },
  {
    id: "sunset",
    label: "Golden Sunset",
    skyDayTop: "#4a6cf7",
    skyDayMid: "#ff9a3d",
    skyDayBot: "#ffe29a",
    skyNightTop: "#12082b",
    skyNightMid: "#3d1663",
    skyNightBot: "#8f2d5c",
    hillFar: "#c96f3b",
    hillNear: "#8f4a24",
    cloud: "#ffd9c2",
    bush: "#6e8f2b",
    groundTop: "#e8953d",
    groundBase: "#a34e1a",
    groundDark: "#5c2806",
    grass: "#8fd44f",
  },
  {
    id: "night",
    label: "Midnight Climb",
    skyDayTop: "#141a4d",
    skyDayMid: "#2c3a8f",
    skyDayBot: "#5a6fc4",
    skyNightTop: "#02020f",
    skyNightMid: "#0b1035",
    skyNightBot: "#232a5e",
    hillFar: "#2e4a7b",
    hillNear: "#1b2f52",
    cloud: "#8fa3d9",
    bush: "#1f5c3d",
    groundTop: "#9a7bd4",
    groundBase: "#5b3d99",
    groundDark: "#2c1a52",
    grass: "#4dd8ff",
  },
  {
    id: "cave",
    label: "Deep Caves",
    skyDayTop: "#0d1b3d",
    skyDayMid: "#1d3a6e",
    skyDayBot: "#2f5c9e",
    skyNightTop: "#000000",
    skyNightMid: "#0a0a1f",
    skyNightBot: "#1a1a3d",
    hillFar: "#2b3f66",
    hillNear: "#1a2947",
    cloud: "#5c7ab5",
    bush: "#2b6e8f",
    groundTop: "#7cc4d4",
    groundBase: "#3d7a8f",
    groundDark: "#173a47",
    grass: "#4dd8ff",
    underground: true,
  },
  {
    id: "volcano",
    label: "Volcano Rush",
    skyDayTop: "#2b0f3d",
    skyDayMid: "#8f2d1e",
    skyDayBot: "#ff7b3d",
    skyNightTop: "#0d0202",
    skyNightMid: "#3d0a0a",
    skyNightBot: "#7a1a1a",
    hillFar: "#5c2b2b",
    hillNear: "#3d1a1a",
    cloud: "#3d3d3d",
    bush: "#7a2b1e",
    groundTop: "#4d4d5c",
    groundBase: "#2b2b38",
    groundDark: "#121218",
    grass: "#ff5a00",
  },
];

export const LEVEL_NAMES = [
  { name: "GREEN GREENS", sub: "World 1-1" },
  { name: "ORANGE GROVE", sub: "World 1-2" },
  { name: "STARRY HEIGHTS", sub: "World 1-3" },
  { name: "CRYSTAL CAVERNS", sub: "World 1-4" },
  { name: "EMBER PEAK", sub: "World 1-5" },
];

export const LEVEL_WIDTHS = [150, 170, 195, 215, 235];
export const LEVEL_TIMES = [300, 300, 280, 280, 260];
export const LEVEL_DIFF = [1.0, 1.15, 1.32, 1.5, 1.7];

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function inRange(v: number, a: number, b: number) {
  return v >= a && v <= b;
}

export function buildLevel(index: number): LevelData {
  const idx = Math.max(0, Math.min(4, index));
  const width = LEVEL_WIDTHS[idx];
  const height = ROWS;
  const rand = mulberry32(1234 + idx * 977);
  const tiles: number[][] = Array.from({ length: height }, () => new Array(width).fill(T.EMPTY));
  const coins: CoinSpawn[] = [];
  const enemies: EnemySpawn[] = [];

  const pick = (arr: number[]) => arr[Math.floor(rand() * arr.length)];

  // ---- ground with gaps ----
  const gapCols = new Set<number>();
  const gapCount = 4 + idx * 2;
  let attempts = 0;
  let placed = 0;
  while (placed < gapCount && attempts < 300) {
    attempts++;
    const w = Math.min(2 + Math.floor(rand() * (2 + idx)), 6);
    const x = 16 + Math.floor(rand() * (width - 48));
    // keep spacing
    let ok = true;
    for (let c = x - 9; c < x + w + 9; c++) {
      if (gapCols.has(c)) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    for (let c = x; c < x + w; c++) gapCols.add(c);
    placed++;
    // coin arc over gap
    const arcH = 3;
    for (let i = 0; i < w + 1; i++) {
      const cx = x + i - 0;
      const lift = Math.round(Math.sin((i / w) * Math.PI) * arcH);
      coins.push({ tx: cx, ty: GROUND_ROW - 3 - lift });
    }
  }

  for (let x = 0; x < width; x++) {
    if (gapCols.has(x)) continue;
    tiles[GROUND_ROW][x] = T.GROUND;
    tiles[GROUND_ROW + 1][x] = T.GROUND;
  }

  const solidAt = (x: number) => x >= 0 && x < width && tiles[GROUND_ROW][x] === T.GROUND;
  const areaFree = (x0: number, x1: number) => {
    for (let x = x0; x <= x1; x++) {
      if (!solidAt(x)) return false;
      for (let r = 0; r < GROUND_ROW; r++) {
        if (tiles[r][x] !== T.EMPTY) return false;
      }
    }
    return true;
  };

  // ---- pipes ----
  const pipeCount = 3 + idx;
  let pipes = 0;
  attempts = 0;
  while (pipes < pipeCount && attempts < 200) {
    attempts++;
    const x = 20 + Math.floor(rand() * (width - 55));
    const h = idx === 0 ? pick([2, 2, 3]) : pick([2, 3, 3, 4]);
    if (h >= 4 && idx < 3) continue;
    if (!areaFree(x, x + 1)) continue;
    // don't block checkpoint/flag
    if (inRange(x, Math.floor(width / 2) - 3, Math.floor(width / 2) + 3)) continue;
    if (x > width - 28) continue;
    for (let r = 0; r < h; r++) {
      const row = GROUND_ROW - 1 - r;
      if (r === h - 1) {
        tiles[row][x] = T.PIPE_TL;
        tiles[row][x + 1] = T.PIPE_TR;
      } else {
        tiles[row][x] = T.PIPE_BL;
        tiles[row][x + 1] = T.PIPE_BR;
      }
    }
    pipes++;
    // coins on tall pipes sometimes
    if (rand() < 0.5) coins.push({ tx: x, ty: GROUND_ROW - 1 - h - 1 });
  }

  // ---- floating block clusters ----
  const floatRow = 9;
  const clusterPatterns: string[][] = [
    ["B", "?", "B"],
    ["?"],
    ["B", "M", "B"],
    ["B", "B", "B", "?"],
    ["?", "B", "?"],
    ["B", "?", "B", "B"],
  ];
  const clusterCount = 9 + idx * 2;
  let clusters = 0;
  attempts = 0;
  while (clusters < clusterCount && attempts < 400) {
    attempts++;
    const pat = clusterPatterns[Math.floor(rand() * clusterPatterns.length)];
    const x = 12 + Math.floor(rand() * (width - 40 - pat.length));
    const row = rand() < 0.25 ? floatRow - 2 : floatRow;
    if (x > width - 26) continue;
    let ok = true;
    for (let i = 0; i < pat.length; i++) {
      if (tiles[row][x + i] !== T.EMPTY || tiles[row - 1]?.[x + i] !== T.EMPTY) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    // need ground-ish below (or gap is fine for challenge, but ensure reachable: require solid within 3 cols)
    pat.forEach((p, i) => {
      const c = p === "B" ? T.BRICK : p === "?" ? T.QCOIN : T.QMUSH;
      tiles[row][x + i] = c;
    });
    clusters++;
  }

  // special bricks: star + 1up hidden in brick rows
  {
    // star brick
    for (let a = 0; a < 60; a++) {
      const x = 18 + Math.floor(rand() * (width - 50));
      if (tiles[floatRow][x] === T.BRICK && x < width - 26) {
        tiles[floatRow][x] = T.STAR_BRICK;
        break;
      }
    }
    for (let a = 0; a < 60; a++) {
      const x = 18 + Math.floor(rand() * (width - 50));
      if (tiles[floatRow][x] === T.BRICK && x < width - 26) {
        tiles[floatRow][x] = T.ONEUP_BRICK;
        break;
      }
    }
  }

  // ---- wood / metal platforms with coins ----
  const platCount = 4 + idx;
  let plats = 0;
  attempts = 0;
  while (plats < platCount && attempts < 200) {
    attempts++;
    const len = 3 + Math.floor(rand() * 3);
    const x = 16 + Math.floor(rand() * (width - 44 - len));
    const row = pick([7, 8, 9]);
    if (x > width - 26) continue;
    let ok = true;
    for (let i = 0; i < len; i++) {
      if (tiles[row][x + i] !== T.EMPTY) {
        ok = false;
        break;
      }
    }
    if (!ok) continue;
    for (let i = 0; i < len; i++) {
      tiles[row][x + i] = idx >= 3 ? T.METAL : T.WOOD;
      if (i % 2 === 0) coins.push({ tx: x + i, ty: row - 1 });
    }
    plats++;
  }

  // coin lines in the air
  for (let i = 0; i < 6 + idx * 2; i++) {
    const x = 12 + Math.floor(rand() * (width - 40));
    const row = pick([8, 9, 10]);
    const len = 3 + Math.floor(rand() * 3);
    if (x > width - 26) continue;
    for (let k = 0; k < len; k++) {
      if (tiles[row][x + k] === T.EMPTY) coins.push({ tx: x + k, ty: row });
    }
  }

  // ---- spikes (from level 2+) ----
  if (idx >= 1) {
    const spikeCount = idx * 2;
    let s = 0;
    attempts = 0;
    while (s < spikeCount && attempts < 200) {
      attempts++;
      const x = 24 + Math.floor(rand() * (width - 60));
      if (!solidAt(x) || !solidAt(x + 1)) continue;
      if (x > width - 28) continue;
      if (tiles[GROUND_ROW - 1][x] !== T.EMPTY) continue;
      tiles[GROUND_ROW - 1][x] = T.SPIKE;
      s++;
    }
  }

  // ---- stairs before flag ----
  const stairH = 4 + Math.min(idx, 4);
  const stairX = width - 24;
  for (let i = 0; i < stairH; i++) {
    for (let r = 0; r <= i; r++) {
      const row = GROUND_ROW - 1 - r;
      const col = stairX + i;
      if (col < width && row >= 0) tiles[row][col] = T.STONE;
    }
  }
  // small down-stairs after gap
  const downX = stairX + stairH + 2;
  for (let i = 0; i < 4; i++) {
    for (let r = 0; r < 4 - i; r++) {
      const row = GROUND_ROW - 1 - r;
      const col = downX + i;
      if (col < width - 12 && row >= 0) tiles[row][col] = T.STONE;
    }
  }

  // ---- flag & castle ground ----
  const flagCol = width - 10;
  const castleCol = width - 6;
  for (let r = 4; r <= GROUND_ROW - 1; r++) tiles[r][flagCol] = T.FLAG;
  tiles[3][flagCol] = T.FLAG_TOP;

  // ---- enemies ----
  const walkerCount = 7 + idx * 2;
  const turtleCount = 2 + idx * 2;
  const flyerCount = idx === 0 ? 0 : 1 + idx;
  const spikyCount = idx < 2 ? 0 : idx;

  const tryPlaceGround = (type: EnemyType) => {
    for (let a = 0; a < 80; a++) {
      const x = 14 + Math.floor(rand() * (width - 46));
      if (x < 14 || x > width - 28) continue;
      if (!solidAt(x)) continue;
      if (tiles[GROUND_ROW - 1][x] !== T.EMPTY) continue;
      // keep start safe
      if (x < 14) continue;
      enemies.push({ type, tx: x, ty: GROUND_ROW - 1 });
      return;
    }
  };
  for (let i = 0; i < walkerCount; i++) tryPlaceGround("walker");
  for (let i = 0; i < turtleCount; i++) tryPlaceGround("turtle");
  for (let i = 0; i < spikyCount; i++) tryPlaceGround("spiky");
  for (let i = 0; i < flyerCount; i++) {
    for (let a = 0; a < 60; a++) {
      const x = 20 + Math.floor(rand() * (width - 55));
      const row = pick([6, 7, 8]);
      if (x > width - 28) continue;
      if (tiles[row][x] !== T.EMPTY) continue;
      enemies.push({ type: "flyer", tx: x, ty: row });
      break;
    }
  }

  return {
    index: idx,
    name: LEVEL_NAMES[idx].name,
    sub: LEVEL_NAMES[idx].sub,
    width,
    height,
    tiles,
    coins,
    enemies,
    playerStart: { tx: 2, ty: GROUND_ROW - 1 },
    flagCol,
    castleCol,
    checkpointCol: Math.floor(width / 2),
    timeLimit: LEVEL_TIMES[idx],
    theme: THEMES[idx],
    baseDifficulty: LEVEL_DIFF[idx],
  };
}
