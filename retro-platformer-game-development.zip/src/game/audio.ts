// Retro WebAudio synth: SFX + adaptive chiptune music.
// All sounds synthesized — no external files.

type OscType = OscillatorType;

class RetroAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  enabled = true;
  private musicTimer: number | null = null;
  private step = 0;
  private nextTime = 0;
  tempoScale = 1;

  private ensure() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.9;
      this.master.connect(this.ctx.destination);
      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = 0.16;
      this.musicGain.connect(this.master);
      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = 0.5;
      this.sfxGain.connect(this.master);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  unlock() {
    this.ensure();
  }

  setEnabled(v: boolean) {
    this.enabled = v;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(v ? 0.9 : 0, this.ctx.currentTime, 0.02);
    }
    if (!v) this.stopMusic();
  }

  private tone(
    freq: number,
    dur: number,
    type: OscType = "square",
    vol = 1,
    slideTo?: number,
    delay = 0
  ) {
    if (!this.enabled) return;
    this.ensure();
    if (!this.ctx || !this.sfxGain) return;
    const t0 = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo !== undefined) o.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(this.sfxGain);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  }

  private noise(dur: number, vol = 1, delay = 0, lowpass = 1200) {
    if (!this.enabled) return;
    this.ensure();
    if (!this.ctx || !this.sfxGain) return;
    const t0 = this.ctx.currentTime + delay;
    const len = Math.max(1, Math.floor(this.ctx.sampleRate * dur));
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.value = lowpass;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(this.sfxGain);
    src.start(t0);
  }

  // ---------- SFX ----------
  jump(big: boolean) {
    this.tone(big ? 180 : 220, 0.18, "square", 0.5, big ? 660 : 880);
  }
  coin() {
    this.tone(988, 0.09, "square", 0.45);
    this.tone(1319, 0.32, "square", 0.45, undefined, 0.09);
  }
  stomp() {
    this.noise(0.16, 0.7, 0, 900);
    this.tone(320, 0.12, "triangle", 0.6, 90);
  }
  kick() {
    this.tone(500, 0.12, "sawtooth", 0.4, 1200);
  }
  bump() {
    this.tone(140, 0.12, "square", 0.6, 90);
    this.noise(0.08, 0.3, 0, 600);
  }
  brick() {
    this.noise(0.28, 0.8, 0, 2400);
    this.tone(220, 0.15, "sawtooth", 0.35, 60);
  }
  sprout() {
    this.tone(300, 0.35, "sine", 0.5, 900);
  }
  powerup() {
    const seq = [523, 659, 784, 1047, 1319, 1568];
    seq.forEach((f, i) => this.tone(f, 0.12, "square", 0.4, undefined, i * 0.07));
  }
  shrink() {
    const seq = [800, 600, 450, 300, 200];
    seq.forEach((f, i) => this.tone(f, 0.12, "sawtooth", 0.35, undefined, i * 0.07));
  }
  fireball() {
    this.tone(880, 0.12, "sawtooth", 0.35, 220);
  }
  oneUp() {
    const seq = [659, 784, 1319, 1047, 1175, 1568];
    seq.forEach((f, i) => this.tone(f, 0.14, "square", 0.4, undefined, i * 0.09));
  }
  death() {
    const seq = [494, 466, 440, 415, 392, 330, 262];
    seq.forEach((f, i) => this.tone(f, 0.16, "square", 0.45, undefined, i * 0.11));
    this.tone(120, 0.6, "triangle", 0.5, 40, 0.7);
  }
  flag() {
    const seq = [392, 523, 659, 784, 1047, 1319, 1568, 2093];
    seq.forEach((f, i) => this.tone(f, 0.13, "square", 0.4, undefined, i * 0.08));
  }
  castle() {
    const seq = [523, 659, 784, 1047, 784, 1047];
    seq.forEach((f, i) => this.tone(f, 0.18, "triangle", 0.5, undefined, i * 0.13));
  }
  warning() {
    for (let i = 0; i < 3; i++) {
      this.tone(660, 0.12, "square", 0.5, undefined, i * 0.18);
      this.tone(440, 0.12, "square", 0.5, undefined, i * 0.18 + 0.09);
    }
  }
  checkpoint() {
    this.tone(784, 0.12, "square", 0.4);
    this.tone(1047, 0.25, "square", 0.4, undefined, 0.12);
  }
  select() {
    this.tone(660, 0.08, "square", 0.35, 990);
  }
  gameOver() {
    const seq = [392, 370, 349, 330, 294, 262, 247, 220];
    seq.forEach((f, i) => this.tone(f, 0.22, "triangle", 0.5, undefined, i * 0.16));
  }
  hurt() {
    this.tone(400, 0.25, "sawtooth", 0.5, 80);
  }

  // ---------- MUSIC ----------
  // Original cheerful chiptune loop (lead + bass). Tempo rises with difficulty.
  startMusic() {
    if (!this.enabled) return;
    this.ensure();
    if (!this.ctx || !this.musicGain || this.musicTimer !== null) return;
    this.step = 0;
    this.nextTime = this.ctx.currentTime + 0.06;
    const tick = () => {
      if (!this.ctx || !this.musicGain) return;
      const baseStep = 0.155; // ~194bpm 16ths
      const stepDur = baseStep / this.tempoScale;
      while (this.nextTime < this.ctx.currentTime + 0.25) {
        this.scheduleStep(this.step, this.nextTime, stepDur);
        this.nextTime += stepDur;
        this.step = (this.step + 1) % 128;
      }
      this.musicTimer = window.setTimeout(tick, 60);
    };
    tick();
  }

  stopMusic() {
    if (this.musicTimer !== null) {
      clearTimeout(this.musicTimer);
      this.musicTimer = null;
    }
  }

  private mtone(freq: number, t: number, dur: number, type: OscType, vol: number) {
    if (!this.ctx || !this.musicGain) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(this.musicGain);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  private scheduleStep(step: number, t: number, stepDur: number) {
    // Chord roots: C F G F | C F G C  (each 16 steps)
    const roots = [130.8, 174.6, 196.0, 174.6, 130.8, 174.6, 196.0, 130.8];
    const bar = Math.floor(step / 16) % 8;
    const s = step % 16;
    const root = roots[bar];

    // Bass: root pump on quarters + fifth bounce
    if (s % 4 === 0) this.mtone(root, t, stepDur * 3, "triangle", 0.9);
    else if (s % 4 === 2) this.mtone(root * 1.5, t, stepDur * 2, "triangle", 0.55);
    // Hats: tiny noise via high square blip
    if (s % 2 === 1) this.mtone(6000 + Math.random() * 2000, t, 0.03, "square", 0.05);

    // Lead melody (original, bouncy). 0 = rest.
    const MEL: number[] = [
      523, 0, 659, 0, 784, 0, 659, 0, 880, 0, 784, 659, 523, 0, 0, 0,
      587, 0, 698, 0, 880, 0, 698, 0, 784, 659, 587, 0, 523, 0, 0, 0,
      523, 0, 659, 0, 784, 0, 880, 0, 1047, 880, 784, 659, 698, 784, 880, 0,
      880, 0, 784, 0, 659, 0, 523, 0, 587, 0, 659, 0, 523, 0, 0, 0,
      523, 0, 659, 0, 784, 0, 659, 0, 880, 0, 1047, 0, 880, 784, 659, 0,
      698, 0, 880, 0, 784, 659, 587, 0, 659, 0, 523, 0, 0, 0, 0, 0,
      784, 0, 784, 659, 784, 880, 1047, 0, 880, 784, 659, 784, 698, 0, 587, 0,
      523, 0, 0, 587, 0, 0, 659, 0, 784, 0, 1047, 0, 523, 0, 0, 0,
    ];
    const f = MEL[step % MEL.length];
    if (f) this.mtone(f, t, stepDur * 1.8, "square", 0.5);
    // Sparkle octave on bar starts
    if (s === 0) this.mtone(root * 4, t, stepDur * 2, "sine", 0.25);
  }
}

export const audio = new RetroAudio();
