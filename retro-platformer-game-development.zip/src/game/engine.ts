import { TILE, ROWS, GROUND_ROW, T, buildLevel, type LevelData, type EnemyType } from "./levels";
import type { Skin } from "./skins";
import { audio } from "./audio";

export const VIEW_W = 960;
export const VIEW_H = 540;

export interface HudState {
  score: number;
  coins: number;
  lives: number;
  timeLeft: number;
  elapsed: number;
  difficulty: number;
  rage01: number;
  progress: number;
  levelName: string;
  levelSub: string;
  power: "small" | "big" | "fire";
  star: boolean;
  checkpoint: boolean;
  state: string;
  toast: string;
}

export interface LevelResult {
  score: number;
  coins: number;
  timeLeft: number;
  elapsed: number;
  completed: boolean;
  levelIndex: number;
}

export interface EngineOptions {
  levelIndex: number;
  skin: Skin;
  lives: number;
  sound: boolean;
  onHud: (h: HudState) => void;
  onLevelComplete: (r: LevelResult) => void;
  onGameOver: (r: LevelResult) => void;
}

interface CoinEnt { x: number; y: number; taken: boolean; bob: number }
interface Enemy {
  type: EnemyType; x: number; y: number; w: number; h: number;
  vx: number; vy: number; dir: -1 | 1; onGround: boolean;
  active: boolean; state: "walk" | "shell" | "shellmove" | "dead";
  stateT: number; deadT: number; noHurtT: number; baseY: number; wingT: number; animT: number;
}
interface PowerEnt { kind: "mush" | "flower" | "star" | "oneup"; x: number; y: number; w: number; h: number; vx: number; vy: number; onGround: boolean; emergeT: number; fromX: number; fromY: number }
interface FireEnt { x: number; y: number; w: number; h: number; vx: number; vy: number; dead: boolean }
interface Particle { x: number; y: number; vx: number; vy: number; life: number; maxLife: number; color: string; size: number; grav: number; shape: "rect" | "circle" }
interface Popup { x: number; y: number; text: string; life: number; color: string }
interface CoinPop { x: number; y: number; vy: number; t: number }
interface CloudD { x: number; y: number; s: number; v: number }
interface HillD { x: number; s: number }
interface StarD { x: number; y: number; s: number; tw: number }

const GRAV = 2400;
const MOVE_SPEED = 235;
const RUN_SPEED = 365;
const ACCEL = 2800;
const AIR_ACCEL = 2000;
const FRICTION = 2600;
const JUMP_V = 845;
const MAX_FALL = 980;

function hexLerp(a: string, b: string, t: number): string {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  const m = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return `rgb(${m[0]},${m[1]},${m[2]})`;
}
function clamp(v: number, a: number, b: number) { return Math.max(a, Math.min(b, v)); }
function rand(a: number, b: number) { return a + Math.random() * (b - a); }

export class GameEngine {
  private ctx: CanvasRenderingContext2D;
  private opts: EngineOptions;
  private level: LevelData;
  private tiles: number[][];
  private coins: CoinEnt[] = [];
  private enemies: Enemy[] = [];
  private powers: PowerEnt[] = [];
  private fires: FireEnt[] = [];
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private coinPops: CoinPop[] = [];
  private bounce = new Map<string, number>();

  private player = {
    x: 0, y: 0, w: 24, h: 32, vx: 0, vy: 0,
    face: 1 as 1 | -1, onGround: false, big: false, fire: false,
    starT: 0, invT: 0, coyote: 0, jumpBuf: 0, animT: 0, skidT: 0,
    stompChain: 0, fireCd: 0, squash: 0,
  };

  private camX = 0;
  private input = { left: false, right: false, jump: false, run: false };
  private prevJump = false;
  private prevRun = false;
  private state: "play" | "dying" | "flagslide" | "flagwalk" | "complete" | "gameover" = "play";
  private stateT = 0;
  private score = 0;
  private coinCount = 0;
  private lives: number;
  private elapsed = 0;
  private rageSpawnT = 8;
  private rageStage = 0;
  private shakeT = 0;
  private shakeMag = 0;
  private checkpointOn = false;
  private flagY = 0;
  private flagScoreGiven = false;
  private toast = "";
  private toastT = 0;
  private raf = 0;
  private last = 0;
  private hudT = 0;
  private paused = false;
  private dead = false;
  private finished = false;
  private hurryWarned = false;

  private clouds: CloudD[] = [];
  private hillsFar: HillD[] = [];
  private hillsNear: HillD[] = [];
  private stars: StarD[] = [];
  private time = 0;

  private onKeyDown = (e: KeyboardEvent) => this.key(e, true);
  private onKeyUp = (e: KeyboardEvent) => this.key(e, false);

  constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no ctx");
    this.ctx = ctx;
    this.opts = opts;
    this.level = buildLevel(opts.levelIndex);
    this.tiles = this.level.tiles.map((r) => [...r]);
    this.lives = opts.lives;

    // coins
    for (const c of this.level.coins) {
      this.coins.push({ x: c.tx * TILE + TILE / 2, y: c.ty * TILE + TILE / 2, taken: false, bob: Math.random() * 6 });
    }
    // enemies
    for (const s of this.level.enemies) this.spawnEnemy(s.type, s.tx, s.ty);

    const ps = this.level.playerStart;
    this.player.x = ps.tx * TILE + 6;
    this.player.y = (ps.ty + 1) * TILE - this.player.h;

    // decor
    const lw = this.level.width * TILE;
    for (let i = 0; i < Math.floor(lw / 260); i++) this.clouds.push({ x: Math.random() * lw, y: rand(30, 220), s: rand(0.7, 1.5), v: rand(4, 14) });
    for (let i = 0; i < Math.floor(lw / 420); i++) this.hillsFar.push({ x: Math.random() * lw, s: rand(1, 1.8) });
    for (let i = 0; i < Math.floor(lw / 300); i++) this.hillsNear.push({ x: Math.random() * lw, s: rand(0.7, 1.3) });
    for (let i = 0; i < 140; i++) this.stars.push({ x: Math.random(), y: Math.random() * 0.7, s: rand(0.6, 2), tw: Math.random() * 6 });

    this.flagY = 4 * TILE;

    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    this.ctx.imageSmoothingEnabled = false;

    if (opts.sound) audio.startMusic();
    this.showToast(`${this.level.sub} — ${this.level.name}`, 2.6);
    this.pushHud(true);
  }

  // ---------------- input ----------------
  private key(e: KeyboardEvent, down: boolean) {
    const c = e.code;
    const jumpKeys = ["Space", "ArrowUp", "KeyW", "KeyZ"];
    const runKeys = ["ShiftLeft", "ShiftRight", "KeyX", "KeyJ"];
    const leftKeys = ["ArrowLeft", "KeyA"];
    const rightKeys = ["ArrowRight", "KeyD"];
    if (jumpKeys.includes(c) || leftKeys.includes(c) || rightKeys.includes(c) || c === "ArrowDown" || c === "KeyS") e.preventDefault();
    if (leftKeys.includes(c)) this.input.left = down;
    else if (rightKeys.includes(c)) this.input.right = down;
    else if (jumpKeys.includes(c)) this.input.jump = down;
    else if (runKeys.includes(c)) this.input.run = down;
  }

  setTouch(left: boolean, right: boolean, jump: boolean, run: boolean) {
    this.input.left = left;
    this.input.right = right;
    this.input.jump = jump;
    this.input.run = run;
  }
  pressFire() {
    this.tryShoot();
  }

  setPaused(p: boolean) {
    this.paused = p;
    this.pushHud(true);
  }

  setSound(v: boolean) {
    this.opts.sound = v;
    if (!v) audio.stopMusic();
    else if (this.state === "play") audio.startMusic();
  }
  get isPaused() { return this.paused; }

  start() {
    this.last = performance.now();
    const loop = (t: number) => {
      if (this.dead) return;
      const dt = clamp((t - this.last) / 1000, 0, 1 / 30);
      this.last = t;
      if (!this.paused) this.update(dt);
      this.render();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
  }

  destroy() {
    this.dead = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    audio.stopMusic();
  }

  private sfx(fn: () => void) {
    if (this.opts.sound) fn();
  }

  // ---------------- difficulty ----------------
  private rage01() {
    return clamp(this.elapsed / 170, 0, 1);
  }
  difficulty() {
    return this.level.baseDifficulty * (1 + this.rage01() * 0.85);
  }
  timeLeft() {
    return Math.max(0, Math.ceil(this.level.timeLimit - this.elapsed));
  }

  private showToast(msg: string, dur = 2.2) {
    this.toast = msg;
    this.toastT = dur;
  }

  // ---------------- spawning ----------------
  private spawnEnemy(type: EnemyType, tx: number, ty: number) {
    if (type === "flyer") {
      const x = tx * TILE + 3;
      const y = ty * TILE + 2;
      this.enemies.push({ type, x, y, w: 30, h: 26, vx: 0, vy: 0, dir: -1, onGround: false, active: false, state: "walk", stateT: 0, deadT: 0, noHurtT: 0, baseY: y, wingT: Math.random() * 6, animT: Math.random() * 6 });
    } else {
      const w = type === "turtle" ? 30 : 30;
      const h = type === "turtle" ? 36 : type === "spiky" ? 30 : 30;
      const x = tx * TILE + 3;
      const y = (ty + 1) * TILE - h;
      this.enemies.push({ type, x, y, w, h, vx: 0, vy: 0, dir: Math.random() < 0.5 ? -1 : 1, onGround: false, active: false, state: "walk", stateT: 0, deadT: 0, noHurtT: 0, baseY: y, wingT: 0, animT: Math.random() * 6 });
    }
  }

  private spawnRageFlyer() {
    const x = this.camX + VIEW_W + 60;
    const tx = Math.floor(x / TILE);
    if (tx >= this.level.width - 12) return;
    if (this.enemies.filter((e) => e.state !== "dead").length > 26) return;
    const y = rand(120, 300);
    this.enemies.push({ type: "flyer", x, y, w: 30, h: 26, vx: 0, vy: 0, dir: -1, onGround: false, active: true, state: "walk", stateT: 0, deadT: 0, noHurtT: 0, baseY: y, wingT: 0, animT: 0 });
    this.burst(x, y, "#c084fc", 8, 160);
  }

  // ---------------- tiles ----------------
  private tileAt(tx: number, ty: number): number {
    if (tx < 0 || tx >= this.level.width) return T.METAL; // side walls
    if (ty < 0 || ty >= ROWS) return T.EMPTY;
    return this.tiles[ty][tx];
  }
  private isSolid(t: number) {
    return t === T.GROUND || t === T.BRICK || t === T.QCOIN || t === T.QMUSH || t === T.USED || t === T.METAL || t === T.PIPE_TL || t === T.PIPE_TR || t === T.PIPE_BL || t === T.PIPE_BR || t === T.STONE || t === T.WOOD || t === T.STAR_BRICK || t === T.ONEUP_BRICK || t === T.FLAG_TOP;
  }

  private collideMove(e: { x: number; y: number; w: number; h: number; vx: number; vy: number; onGround?: boolean }, isPlayer: boolean, onHead?: (tx: number, ty: number) => void) {
    // X
    e.x += e.vx * this.dtStep;
    let x0 = Math.floor(e.x / TILE), x1 = Math.floor((e.x + e.w) / TILE);
    let y0 = Math.floor(e.y / TILE), y1 = Math.floor((e.y + e.h - 1) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.isSolid(this.tileAt(tx, ty))) {
          if (e.vx > 0) e.x = tx * TILE - e.w - 0.01;
          else if (e.vx < 0) e.x = (tx + 1) * TILE + 0.01;
          e.vx = 0;
          x0 = Math.floor(e.x / TILE); x1 = Math.floor((e.x + e.w) / TILE);
        }
      }
    }
    // Y
    e.y += e.vy * this.dtStep;
    if (e.onGround !== undefined) e.onGround = false;
    x0 = Math.floor((e.x + 2) / TILE); x1 = Math.floor((e.x + e.w - 2) / TILE);
    y0 = Math.floor(e.y / TILE); y1 = Math.floor((e.y + e.h) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.isSolid(this.tileAt(tx, ty))) {
          if (e.vy > 0) {
            e.y = ty * TILE - e.h;
            e.vy = 0;
            if (e.onGround !== undefined) e.onGround = true;
          } else if (e.vy < 0) {
            e.y = (ty + 1) * TILE + 0.01;
            e.vy = 0;
            if (isPlayer && onHead) onHead(tx, ty);
          }
          y0 = Math.floor(e.y / TILE); y1 = Math.floor((e.y + e.h) / TILE);
        }
      }
    }
  }

  private dtStep = 1 / 60;

  // ---------------- block hits ----------------
  private hitBlock(tx: number, ty: number) {
    const t = this.tileAt(tx, ty);
    const cx = tx * TILE + TILE / 2;
    if (t === T.QCOIN) {
      this.tiles[ty][tx] = T.USED;
      this.bounce.set(tx + "," + ty, 0.18);
      this.coinPops.push({ x: cx, y: ty * TILE - 6, vy: -520, t: 0 });
      this.addCoin(1, cx, ty * TILE - 10);
      this.sfx(() => audio.coin());
    } else if (t === T.QMUSH) {
      this.tiles[ty][tx] = T.USED;
      this.bounce.set(tx + "," + ty, 0.18);
      const kind = this.player.fire || !this.player.big ? (this.player.big ? "flower" : "mush") : "flower";
      this.powers.push({ kind: this.player.big ? "flower" : kind, x: tx * TILE + 3, y: ty * TILE - 30, w: 30, h: 30, vx: 0, vy: 0, onGround: false, emergeT: 0.7, fromX: tx * TILE + 3, fromY: ty * TILE });
      this.sfx(() => audio.sprout());
    } else if (t === T.BRICK) {
      if (this.player.big) {
        this.tiles[ty][tx] = T.EMPTY;
        this.sfx(() => audio.brick());
        this.addScore(50, cx, ty * TILE);
        this.shake(0.12, 4);
        for (let i = 0; i < 6; i++) {
          this.particles.push({ x: cx + rand(-14, 14), y: ty * TILE + rand(0, 20), vx: rand(-220, 220), vy: rand(-500, -100), life: 0.8, maxLife: 0.8, color: i % 2 ? "#e8792e" : "#a34a00", size: rand(4, 8), grav: 1800, shape: "rect" });
        }
      } else {
        this.bounce.set(tx + "," + ty, 0.18);
        this.sfx(() => audio.bump());
        // bump enemies standing on it
        for (const en of this.enemies) {
          if (en.state === "dead") continue;
          const feetRow = Math.floor((en.y + en.h + 4) / TILE);
          const midCol = Math.floor((en.x + en.w / 2) / TILE);
          if (feetRow === ty && midCol === tx) this.killEnemy(en, false);
        }
      }
    } else if (t === T.STAR_BRICK) {
      this.tiles[ty][tx] = T.USED;
      this.bounce.set(tx + "," + ty, 0.18);
      this.powers.push({ kind: "star", x: tx * TILE + 3, y: ty * TILE - 30, w: 28, h: 28, vx: 0, vy: 0, onGround: false, emergeT: 0.7, fromX: tx * TILE + 3, fromY: ty * TILE });
      this.sfx(() => audio.sprout());
    } else if (t === T.ONEUP_BRICK) {
      this.tiles[ty][tx] = T.USED;
      this.bounce.set(tx + "," + ty, 0.18);
      this.powers.push({ kind: "oneup", x: tx * TILE + 3, y: ty * TILE - 30, w: 30, h: 30, vx: 0, vy: 0, onGround: false, emergeT: 0.7, fromX: tx * TILE + 3, fromY: ty * TILE });
      this.sfx(() => audio.sprout());
    } else if (t === T.USED || t === T.METAL || t === T.STONE || t === T.WOOD) {
      this.sfx(() => audio.bump());
    }
  }

  private addScore(n: number, x?: number, y?: number) {
    this.score += n;
    if (x !== undefined && y !== undefined) this.popups.push({ x, y, text: `+${n}`, life: 0.9, color: "#ffffff" });
  }
  private addCoin(n: number, x?: number, y?: number) {
    this.coinCount += n;
    this.score += 200 * n;
    if (x !== undefined && y !== undefined) this.popups.push({ x, y, text: `+${200 * n}`, life: 0.8, color: "#ffd700" });
    this.pushHud(true);
  }

  private burst(x: number, y: number, color: string, n: number, spd: number) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      this.particles.push({ x, y, vx: Math.cos(a) * spd * rand(0.3, 1), vy: Math.sin(a) * spd * rand(0.3, 1) - 120, life: rand(0.3, 0.7), maxLife: 0.7, color, size: rand(3, 6), grav: 900, shape: Math.random() < 0.5 ? "rect" : "circle" });
    }
  }
  private shake(t: number, m: number) {
    this.shakeT = Math.max(this.shakeT, t);
    this.shakeMag = m;
  }

  // ---------------- combat ----------------
  private killEnemy(en: Enemy, stomp: boolean) {
    if (en.state === "dead") return;
    en.state = "dead";
    en.deadT = stomp ? 0.4 : 0.9;
    if (stomp) {
      en.vx = 0; en.vy = 0;
      this.player.stompChain++;
      const pts = Math.min(100 * Math.pow(2, this.player.stompChain - 1), 1600);
      this.addScore(pts, en.x + en.w / 2, en.y - 8);
      this.sfx(() => audio.stomp());
      this.burst(en.x + en.w / 2, en.y + en.h / 2, "#ffffff", 6, 140);
    } else {
      en.vy = -420;
      this.addScore(200, en.x + en.w / 2, en.y - 8);
      this.sfx(() => audio.kick());
    }
  }

  private hurtPlayer(fromX: number) {
    const p = this.player;
    if (p.invT > 0 || p.starT > 0 || this.state !== "play") return;
    if (p.fire) {
      p.fire = false;
      p.invT = 2;
      this.sfx(() => audio.shrink());
      this.showToast("Fire power lost!", 1.4);
      this.burst(p.x + p.w / 2, p.y + p.h / 2, "#ff7b00", 10, 200);
    } else if (p.big) {
      p.big = false;
      p.y += (52 - 32);
      p.h = 32; p.w = 24;
      p.invT = 2;
      this.sfx(() => audio.shrink());
      this.burst(p.x + p.w / 2, p.y + p.h / 2, "#ffffff", 10, 200);
    } else {
      this.startDeath(false);
      return;
    }
    p.vx = (p.x + p.w / 2 < fromX ? -1 : 1) * 220;
    p.vy = -320;
  }

  private startDeath(timeUp: boolean) {
    if (this.state !== "play") return;
    this.state = "dying";
    this.stateT = 0;
    void timeUp;
    this.player.vy = -720;
    this.player.vx = 0;
    this.sfx(() => audio.death());
    audio.stopMusic();
    this.showToast(timeUp ? "TIME UP!" : "OUCH!", 2);
  }

  private tryShoot() {
    const p = this.player;
    if (this.state !== "play" || !p.fire || p.fireCd > 0) return;
    if (this.fires.length >= 3) return;
    p.fireCd = 0.28;
    this.fires.push({ x: p.x + p.w / 2 + p.face * 14 - 6, y: p.y + p.h / 2 - 8, w: 14, h: 14, vx: p.face * 520, vy: -120, dead: false });
    this.sfx(() => audio.fireball());
  }

  // ---------------- update ----------------
  private update(rawDt: number) {
    const dt = rawDt;
    this.dtStep = dt;
    this.time += dt;

    // toast timer
    if (this.toastT > 0) {
      this.toastT -= dt;
      if (this.toastT <= 0) this.toast = "";
    }
    // bounce anims
    for (const [k, v] of [...this.bounce]) {
      const nv = v - dt;
      if (nv <= 0) this.bounce.delete(k);
      else this.bounce.set(k, nv);
    }
    // particles/popups/coinpops always update
    this.updateFx(dt);

    if (this.state === "dying") {
      this.stateT += dt;
      this.player.vy += GRAV * dt;
      this.player.y += this.player.vy * dt;
      if (this.stateT > 2.3) {
        this.lives--;
        if (this.lives <= 0) {
          this.state = "gameover";
          this.sfx(() => audio.gameOver());
          this.finish(false);
        } else {
          this.respawn();
        }
      }
      this.pushHud();
      return;
    }

    if (this.state === "flagslide" || this.state === "flagwalk") {
      this.updateFlagSeq(dt);
      this.updateEnemies(dt, true);
      this.updateCamera(dt);
      this.pushHud();
      return;
    }
    if (this.state === "complete" || this.state === "gameover") {
      this.updateEnemies(dt, true);
      this.pushHud();
      return;
    }

    // ---- play ----
    this.elapsed += dt;
    const tl = this.timeLeft();
    audio.tempoScale = 1 + this.rage01() * 0.4 + (tl <= 30 ? 0.25 : 0);

    if (!this.hurryWarned && tl <= 30 && tl > 0) {
      this.hurryWarned = true;
      this.showToast("HURRY! Time is running out!", 2.4);
      this.sfx(() => audio.warning());
    }
    if (tl <= 0) {
      this.startDeath(true);
      return;
    }

    // rage stages
    const r = this.rage01();
    if (this.rageStage === 0 && this.elapsed > 30) {
      this.rageStage = 1;
      this.showToast("The shadows grow... enemies quicken!", 2.6);
      this.sfx(() => audio.warning());
    } else if (this.rageStage === 1 && this.elapsed > 75) {
      this.rageStage = 2;
      this.showToast("ENEMIES ENRAGED! Keep moving!", 2.6);
      this.sfx(() => audio.warning());
    } else if (this.rageStage === 2 && this.elapsed > 125) {
      this.rageStage = 3;
      this.showToast("MAXIMUM RAGE! Good luck!", 2.6);
      this.sfx(() => audio.warning());
    }

    // rage spawner
    if (this.elapsed > 40) {
      this.rageSpawnT -= dt;
      if (this.rageSpawnT <= 0) {
        this.spawnRageFlyer();
        this.rageSpawnT = Math.max(13 - r * 8 - this.level.index, 4.5);
      }
    }

    this.updatePlayer(dt);
    this.updateEnemies(dt, false);
    this.updatePowers(dt);
    this.updateFires(dt);
    this.checkPickups();
    this.checkCheckpoint();
    this.checkFlag();
    this.updateCamera(dt);

    // fell in pit
    if (this.player.y > ROWS * TILE + 30) {
      this.startDeath(false);
    }

    // jump edge tracking
    this.prevJump = this.input.jump;
    this.prevRun = this.input.run;
    this.pushHud();
  }

  private updateFx(dt: number) {
    for (const c of this.clouds) {
      c.x += c.v * dt;
      if (c.x > this.level.width * TILE + 100) c.x = -100;
    }
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) { this.particles.splice(i, 1); continue; }
      p.vy += p.grav * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const p = this.popups[i];
      p.life -= dt;
      p.y -= 46 * dt;
      if (p.life <= 0) this.popups.splice(i, 1);
    }
    for (let i = this.coinPops.length - 1; i >= 0; i--) {
      const c = this.coinPops[i];
      c.t += dt;
      c.vy += 2200 * dt;
      c.y += c.vy * dt;
      if (c.t > 0.55) this.coinPops.splice(i, 1);
    }
    if (this.shakeT > 0) this.shakeT -= this.dtStep;
  }

  private updatePlayer(dt: number) {
    const p = this.player;
    const running = this.input.run;
    const maxSpeed = running ? RUN_SPEED : MOVE_SPEED;

    // horizontal
    const want = (this.input.right ? 1 : 0) - (this.input.left ? 1 : 0);
    if (want !== 0) {
      if (p.onGround && Math.sign(p.vx) === -want && Math.abs(p.vx) > 180) {
        p.skidT = 0.15;
        if (Math.random() < 0.4) this.particles.push({ x: p.x + p.w / 2, y: p.y + p.h - 2, vx: rand(-60, 60), vy: rand(-120, -30), life: 0.3, maxLife: 0.3, color: "#ffffff", size: 3, grav: 500, shape: "circle" });
      }
      p.vx += want * (p.onGround ? ACCEL : AIR_ACCEL) * dt;
      p.vx = clamp(p.vx, -maxSpeed, maxSpeed);
      p.face = want > 0 ? 1 : -1;
    } else {
      const f = (p.onGround ? FRICTION : 500) * dt;
      if (Math.abs(p.vx) <= f) p.vx = 0;
      else p.vx -= Math.sign(p.vx) * f;
    }

    // jumping
    if (p.onGround) {
      p.coyote = 0.09;
      p.stompChain = 0;
    } else p.coyote -= dt;
    if (this.input.jump && !this.prevJump) p.jumpBuf = 0.12;
    else p.jumpBuf -= dt;
    if (p.jumpBuf > 0 && p.coyote > 0) {
      p.vy = -JUMP_V * (running && Math.abs(p.vx) > 300 ? 1.06 : 1);
      p.onGround = false;
      p.coyote = 0;
      p.jumpBuf = 0;
      p.squash = -0.25;
      this.sfx(() => audio.jump(p.big));
      this.burst(p.x + p.w / 2, p.y + p.h, "#ffffff", 4, 90);
    }
    // variable jump
    if (!this.input.jump && p.vy < -280) p.vy += GRAV * 2.2 * dt;

    p.vy += GRAV * dt;
    if (p.vy > MAX_FALL) p.vy = MAX_FALL;

    // fire on run-press edge
    if (this.input.run && !this.prevRun) this.tryShoot();
    if (p.fireCd > 0) p.fireCd -= dt;

    const wasGround = p.onGround;
    const fallV = p.vy;
    this.collideMove(p, true, (tx, ty) => this.hitBlock(tx, ty));
    if (!wasGround && p.onGround && fallV > 500) {
      p.squash = 0.3;
      this.burst(p.x + p.w / 2, p.y + p.h, "#e8e8e8", 4, 80);
    }

    p.x = clamp(p.x, 0, this.level.width * TILE - p.w);
    p.animT += dt * (Math.abs(p.vx) / 60 + (p.onGround ? 0.5 : 0));
    if (p.invT > 0) p.invT -= dt;
    if (p.starT > 0) {
      p.starT -= dt;
      if (Math.random() < 0.5) this.particles.push({ x: p.x + rand(0, p.w), y: p.y + rand(0, p.h), vx: rand(-40, 40), vy: rand(-80, -20), life: 0.4, maxLife: 0.4, color: ["#ffd700", "#00e5ff", "#ff5da2", "#7bff00"][Math.floor(Math.random() * 4)], size: 4, grav: 0, shape: "circle" });
    }
    if (p.skidT > 0) p.skidT -= dt;
    p.squash *= 1 - Math.min(1, dt * 10);
  }

  private updateEnemies(dt: number, frozen: boolean) {
    const diff = this.difficulty();
    const camL = this.camX - 80, camR = this.camX + VIEW_W + 160;
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      if (e.state === "dead") {
        e.deadT -= dt;
        if (e.deadT <= 0) { this.enemies.splice(i, 1); continue; }
        // stomped foes stay squashed on the ground; kicked ones tumble away
        if (e.deadT > 0.45) { e.vy += GRAV * dt; e.y += e.vy * dt; e.x += 130 * dt; }
        continue;
      }
      if (!e.active) {
        if (e.x + e.w > camL && e.x < camR) {
          e.active = true;
          const sp = this.baseSpeed(e.type) * diff;
          e.vx = sp * e.dir;
        } else continue;
      }
      if (e.x + e.w < this.camX - 240 || e.y > ROWS * TILE + 80) {
        this.enemies.splice(i, 1);
        continue;
      }
      e.animT += dt;
      e.wingT += dt;
      if (e.noHurtT > 0) e.noHurtT -= dt;

      if (frozen) continue;

      if (e.type === "flyer") {
        const sp = this.baseSpeed("flyer") * diff;
        // drift toward player x, sine y
        const px = this.player.x + this.player.w / 2;
        const dir = px < e.x ? -1 : 1;
        e.x += dir * sp * 0.55 * dt;
        e.y = e.baseY + Math.sin(e.wingT * 3) * 22;
        // slight vertical chase when raging
        if (this.rage01() > 0.5) e.baseY += clamp((this.player.y - e.baseY) * 0.4, -40, 40) * dt;
        e.dir = dir as -1 | 1;
      } else if (e.state === "shell") {
        e.vx = 0;
        e.vy += GRAV * dt;
        this.collideMove(e, false);
        e.stateT -= dt;
        if (e.stateT <= 0) {
          // wake up
          e.state = "walk";
          e.h = 36;
          e.y -= (36 - 22);
        }
      } else if (e.state === "shellmove") {
        const sp = 380 * Math.min(diff, 1.8);
        e.vx = sp * e.dir;
        const oldVx = e.vx;
        e.vy += GRAV * dt;
        if (e.vy > MAX_FALL) e.vy = MAX_FALL;
        this.collideMove(e, false);
        if (e.vx === 0 && oldVx !== 0) {
          e.dir = (e.dir * -1) as -1 | 1;
          this.sfx(() => audio.bump());
        }
        // kill other enemies
        for (const o of this.enemies) {
          if (o === e || o.state === "dead") continue;
          if (this.overlap(e, o)) {
            this.killEnemy(o, false);
            this.addScore(200, o.x, o.y - 8);
          }
        }
      } else {
        // walk
        const sp = this.baseSpeed(e.type) * diff;
        e.vx = sp * e.dir;
        e.vy += GRAV * dt;
        if (e.vy > MAX_FALL) e.vy = MAX_FALL;
        const beforeX = e.x;
        this.collideMove(e, false);
        if (Math.abs(e.x - beforeX) < 0.5 && e.vx === 0) e.dir = (e.dir * -1) as -1 | 1;
        // turtle turns at ledges
        if (e.type === "turtle" && e.onGround) {
          const aheadX = e.dir > 0 ? e.x + e.w + 4 : e.x - 4;
          const tx = Math.floor(aheadX / TILE);
          const ty = Math.floor((e.y + e.h + 6) / TILE);
          if (!this.isSolid(this.tileAt(tx, ty))) e.dir = (e.dir * -1) as -1 | 1;
        }
      }

      // interact with player
      if (this.state === "play") this.enemyPlayer(e);
    }
  }

  private baseSpeed(t: EnemyType) {
    switch (t) {
      case "walker": return 62;
      case "turtle": return 72;
      case "spiky": return 58;
      case "flyer": return 95;
    }
  }

  private overlap(a: { x: number; y: number; w: number; h: number }, b: { x: number; y: number; w: number; h: number }) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  private enemyPlayer(e: Enemy) {
    const p = this.player;
    if (!this.overlap(p, e)) return;
    // star kills everything
    if (p.starT > 0) {
      this.killEnemy(e, false);
      p.vy = -420;
      return;
    }
    const stomping = p.vy > 60 && (p.y + p.h - e.y) < e.h * 0.62;

    if (e.type === "spiky") {
      if (stomping) {
        this.hurtPlayer(e.x + e.w / 2);
        p.vy = -560;
      } else this.hurtPlayer(e.x + e.w / 2);
      return;
    }
    if (e.type === "turtle" && (e.state === "shell" || e.state === "shellmove")) {
      if (e.state === "shellmove") {
        if (stomping) {
          e.state = "shell";
          e.stateT = 6;
          e.vx = 0;
          p.y = e.y - p.h - 1;
          p.vy = -560;
          this.sfx(() => audio.stomp());
          this.addScore(100, e.x, e.y - 10);
        } else if (e.noHurtT <= 0) {
          this.hurtPlayer(e.x + e.w / 2);
        }
      } else {
        // stopped shell: stomp or kick
        if (stomping) {
          // kick it
          e.state = "shellmove";
          e.dir = (p.x + p.w / 2 < e.x + e.w / 2 ? 1 : -1) as -1 | 1;
          e.noHurtT = 0.25;
          p.y = e.y - p.h - 1;
          p.vy = -560;
          this.sfx(() => audio.kick());
          this.addScore(100, e.x, e.y - 10);
        } else {
          // side kick
          e.state = "shellmove";
          e.dir = (p.x + p.w / 2 < e.x + e.w / 2 ? 1 : -1) as -1 | 1;
          e.noHurtT = 0.25;
          // nudge player back
          p.x += e.dir > 0 ? -8 : 8;
          this.sfx(() => audio.kick());
          this.addScore(100, e.x, e.y - 10);
        }
      }
      return;
    }
    // normal walker / turtle-walk / flyer
    if (stomping) {
      if (e.type === "turtle" && e.state === "walk") {
        e.state = "shell";
        e.stateT = 7;
        e.h = 22;
        e.y += (36 - 22);
        e.vx = 0;
        p.y = e.y - p.h - 1;
        p.vy = this.input.jump ? -720 : -520;
        this.sfx(() => audio.stomp());
        this.addScore(100, e.x, e.y - 10);
        this.burst(e.x + e.w / 2, e.y, "#ffffff", 5, 120);
      } else {
        this.killEnemy(e, true);
        p.y = e.y - p.h - 1;
        p.vy = this.input.jump ? -720 : -520;
      }
    } else {
      this.hurtPlayer(e.x + e.w / 2);
    }
  }

  private updatePowers(dt: number) {
    for (let i = this.powers.length - 1; i >= 0; i--) {
      const m = this.powers[i];
      if (m.emergeT > 0) {
        m.emergeT -= dt;
        const k = 1 - m.emergeT / 0.7;
        m.y = m.fromY - 30 * k;
        if (m.emergeT <= 0) {
          m.vx = (m.kind === "star" ? 190 : 120) * (this.player.x < m.x ? 1 : -1);
          m.vy = 0;
        }
        continue;
      }
      if (m.kind === "flower") {
        m.vy += GRAV * dt;
        this.collideMove(m, false);
      } else if (m.kind === "star") {
        m.vx = 190 * Math.sign(m.vx || 1);
        m.vy += GRAV * dt;
        const bx = m.x;
        this.collideMove(m, false);
        if (m.x === bx || m.vx === 0) m.vx = -m.vx || 190;
        if (m.onGround) m.vy = -560;
      } else {
        m.vy += GRAV * dt;
        if (m.vy > MAX_FALL) m.vy = MAX_FALL;
        const bx = m.x;
        this.collideMove(m, false);
        if (m.x === bx || m.vx === 0) m.vx = (m.vx === 0 ? 120 : -m.vx);
      }
      if (m.y > ROWS * TILE + 40) { this.powers.splice(i, 1); continue; }
      // pickup
      if (this.overlap(this.player, m)) {
        this.collectPower(m);
        this.powers.splice(i, 1);
      }
    }
  }

  private collectPower(m: PowerEnt) {
    const p = this.player;
    const cx = m.x + m.w / 2, cy = m.y;
    if (m.kind === "mush") {
      if (!p.big) {
        p.big = true;
        p.h = 52; p.w = 26;
        p.y -= (52 - 32);
        this.showToast("SUPER! You grew big!", 1.6);
      } else this.addScore(1000, cx, cy);
      this.addScore(1000, cx, cy);
      this.sfx(() => audio.powerup());
      this.burst(cx, cy + 10, "#ff4d4d", 12, 200);
    } else if (m.kind === "flower") {
      p.big = true; p.fire = true;
      p.h = 52; p.w = 26;
      this.addScore(1000, cx, cy);
      this.sfx(() => audio.powerup());
      this.showToast("FIRE POWER! Press RUN to shoot!", 2.2);
      this.burst(cx, cy + 10, "#ff7b00", 14, 220);
    } else if (m.kind === "star") {
      p.starT = 9;
      this.addScore(1000, cx, cy);
      this.sfx(() => audio.powerup());
      this.showToast("STAR POWER! Invincible!", 2);
    } else {
      this.lives = Math.min(5, this.lives + 1);
      this.popups.push({ x: cx, y: cy, text: "1UP!", life: 1.2, color: "#7bff00" });
      this.sfx(() => audio.oneUp());
    }
    this.pushHud(true);
  }

  private updateFires(dt: number) {
    for (let i = this.fires.length - 1; i >= 0; i--) {
      const f = this.fires[i];
      f.vy += GRAV * 0.9 * dt;
      const bx = f.x;
      this.collideMove(f, false);
      if (f.x === bx && f.vx === 0) { this.fires.splice(i, 1); this.burst(f.x, f.y, "#ff7b00", 4, 120); continue; }
      // bounce
      const feetTy = Math.floor((f.y + f.h + 2) / TILE);
      const midTx = Math.floor((f.x + f.w / 2) / TILE);
      if (this.isSolid(this.tileAt(midTx, feetTy)) && f.vy > 0) f.vy = -380;
      if (Math.random() < 0.4) this.particles.push({ x: f.x + f.w / 2, y: f.y + f.h / 2, vx: rand(-40, 40), vy: rand(-60, 0), life: 0.25, maxLife: 0.25, color: "#ffcf3d", size: 3, grav: 0, shape: "circle" });
      if (f.y > ROWS * TILE || f.x < this.camX - 60 || f.x > this.camX + VIEW_W + 60) { this.fires.splice(i, 1); continue; }
      // hit enemies
      for (const e of this.enemies) {
        if (e.state === "dead") continue;
        if (this.overlap(f, e)) {
          this.killEnemy(e, false);
          f.dead = true;
          this.burst(f.x, f.y, "#ff7b00", 8, 180);
          break;
        }
      }
      if (f.dead) this.fires.splice(i, 1);
    }
  }

  private checkPickups() {
    const p = this.player;
    for (const c of this.coins) {
      if (c.taken) continue;
      if (c.x < this.camX - 40 || c.x > this.camX + VIEW_W + 40) continue;
      const dx = c.x - (p.x + p.w / 2), dy = c.y - (p.y + p.h / 2);
      if (Math.abs(dx) < 30 && Math.abs(dy) < 42) {
        c.taken = true;
        this.addCoin(1, c.x, c.y - 14);
        this.sfx(() => audio.coin());
        this.burst(c.x, c.y, "#ffd700", 6, 150);
      }
    }
    // spike tiles damage
    const x0 = Math.floor(p.x / TILE), x1 = Math.floor((p.x + p.w) / TILE);
    const y0 = Math.floor(p.y / TILE), y1 = Math.floor((p.y + p.h) / TILE);
    for (let ty = y0; ty <= y1; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        if (this.tileAt(tx, ty) === T.SPIKE) {
          if (p.starT > 0) break;
          this.hurtPlayer(tx * TILE);
          p.vy = -420;
          return;
        }
      }
    }
  }

  private checkCheckpoint() {
    if (this.checkpointOn) return;
    if (this.player.x > this.level.checkpointCol * TILE) {
      this.checkpointOn = true;
      this.showToast("CHECKPOINT!", 1.8);
      this.sfx(() => audio.checkpoint());
      this.burst(this.player.x, this.player.y, "#7bff00", 12, 200);
    }
  }

  private checkFlag() {
    const p = this.player;
    const flagX = this.level.flagCol * TILE + TILE / 2;
    if (p.x + p.w >= flagX - 6) {
      this.state = "flagslide";
      this.stateT = 0;
      p.x = flagX - p.w - 2;
      p.vx = 0; p.vy = 0;
      this.sfx(() => audio.flag());
      audio.stopMusic();
      if (!this.flagScoreGiven) {
        this.flagScoreGiven = true;
        const hRatio = 1 - clamp((p.y / (ROWS * TILE)) * 1.4, 0, 1);
        const bonus = 1000 + Math.round(hRatio * 4000);
        this.addScore(bonus, flagX, p.y - 20);
      }
    }
  }

  private updateFlagSeq(dt: number) {
    const p = this.player;
    this.stateT += dt;
    const groundY = GROUND_ROW * TILE - p.h;
    if (this.state === "flagslide") {
      p.y += 260 * dt;
      this.flagY += 200 * dt;
      if (p.y >= groundY) {
        p.y = groundY;
        this.state = "flagwalk";
        this.stateT = 0;
        this.sfx(() => audio.castle());
      }
    } else {
      // walk to castle
      p.face = 1;
      p.x += 140 * dt;
      p.animT += dt * 8;
      const doorX = this.level.castleCol * TILE + TILE * 1.4;
      if (p.x >= doorX) {
        this.state = "complete";
        this.stateT = 0;
        const bonus = this.timeLeft() * 15;
        this.addScore(bonus, p.x, p.y - 30);
        this.burst(p.x, p.y, "#ffd700", 24, 260);
        this.finish(true);
      }
    }
    // flag clamp
    this.flagY = Math.min(this.flagY, (GROUND_ROW - 2) * TILE);
  }

  private respawn() {
    const startTx = this.checkpointOn ? this.level.checkpointCol : this.level.playerStart.tx;
    const p = this.player;
    p.big = false; p.fire = false; p.starT = 0;
    p.w = 24; p.h = 32;
    p.x = startTx * TILE + 6;
    p.y = GROUND_ROW * TILE - p.h;
    p.vx = 0; p.vy = 0;
    p.invT = 2;
    this.elapsed = Math.max(0, this.elapsed - 15); // rage cools a little
    this.camX = clamp(p.x - VIEW_W * 0.4, 0, this.level.width * TILE - VIEW_W);
    this.state = "play";
    this.stateT = 0;
    if (this.opts.sound) audio.startMusic();
    this.showToast(this.checkpointOn ? "Back at checkpoint!" : "Try again!", 1.6);
    this.pushHud(true);
  }

  private finish(completed: boolean) {
    if (this.finished) return;
    this.finished = true;
    const r: LevelResult = {
      score: this.score,
      coins: this.coinCount,
      timeLeft: this.timeLeft(),
      elapsed: Math.round(this.elapsed),
      completed,
      levelIndex: this.level.index,
    };
    window.setTimeout(() => {
      if (completed) this.opts.onLevelComplete(r);
      else this.opts.onGameOver(r);
    }, completed ? 900 : 600);
  }

  private updateCamera(dt: number) {
    const p = this.player;
    const target = clamp(p.x + p.w / 2 - VIEW_W * 0.42 + p.face * 26, 0, this.level.width * TILE - VIEW_W);
    this.camX += (target - this.camX) * Math.min(1, dt * 6);
  }

  private pushHud(force = false) {
    this.hudT -= this.dtStep;
    if (!force && this.hudT > 0) return;
    this.hudT = 0.1;
    const p = this.player;
    this.opts.onHud({
      score: this.score,
      coins: this.coinCount,
      lives: this.lives,
      timeLeft: this.timeLeft(),
      elapsed: this.elapsed,
      difficulty: this.difficulty(),
      rage01: this.rage01(),
      progress: clamp(p.x / (this.level.width * TILE), 0, 1),
      levelName: this.level.name,
      levelSub: this.level.sub,
      power: p.fire ? "fire" : p.big ? "big" : "small",
      star: p.starT > 0,
      checkpoint: this.checkpointOn,
      state: this.paused ? "paused" : this.state,
      toast: this.toast,
    });
  }

  // ================= RENDER =================
  private render() {
    const ctx = this.ctx;
    const th = this.level.theme;
    const rage = this.rage01();
    const baseNight = th.underground ? 0.55 : this.level.index * 0.1;
    const mix = clamp(baseNight + rage * 0.75, 0, 1);

    // sky
    const top = hexLerp(th.skyDayTop, th.skyNightTop, mix);
    const mid = hexLerp(th.skyDayMid, th.skyNightMid, mix);
    const bot = hexLerp(th.skyDayBot, th.skyNightBot, mix);
    const g = ctx.createLinearGradient(0, 0, 0, VIEW_H);
    g.addColorStop(0, top);
    g.addColorStop(0.55, mid);
    g.addColorStop(1, bot);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, VIEW_W, VIEW_H);

    // stars
    if (mix > 0.3) {
      ctx.save();
      ctx.globalAlpha = (mix - 0.3) * 1.4;
      for (const s of this.stars) {
        const tw = 0.5 + 0.5 * Math.sin(this.time * 3 + s.tw);
        ctx.globalAlpha = ((mix - 0.3) * 1.4) * (0.4 + 0.6 * tw);
        ctx.fillStyle = "#ffffff";
        const sx = ((s.x * VIEW_W * 1.5 - this.camX * 0.05) % (VIEW_W + 20) + VIEW_W + 20) % (VIEW_W + 20) - 10;
        ctx.fillRect(sx, s.y * VIEW_H, s.s, s.s);
      }
      ctx.restore();
    }

    // sun / moon
    const sunX = VIEW_W * 0.8 - rage * VIEW_W * 0.5;
    const sunY = 90 + rage * 160;
    ctx.save();
    ctx.globalAlpha = 1 - mix * 0.7;
    ctx.fillStyle = "#ffdf3d";
    ctx.beginPath(); ctx.arc(sunX, sunY, 30, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#ffb700";
    ctx.beginPath(); ctx.arc(sunX, sunY, 24, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    if (mix > 0.25) {
      ctx.save();
      ctx.globalAlpha = (mix - 0.2) * 1.3;
      const mx = VIEW_W * 0.2 + mix * 120;
      const my = 80 + (1 - mix) * 40;
      ctx.fillStyle = "#f4f1de";
      ctx.beginPath(); ctx.arc(mx, my, 24, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = hexLerp(th.skyNightMid, "#000000", 0.2);
      ctx.beginPath(); ctx.arc(mx + 8, my - 6, 20, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    }

    ctx.save();
    // shake
    if (this.shakeT > 0) ctx.translate(rand(-this.shakeMag, this.shakeMag), rand(-this.shakeMag, this.shakeMag));

    this.drawHills(th, mix);
    this.drawClouds(th, mix);
    this.drawTiles(th);
    this.drawCastle();
    this.drawCheckpoint();
    this.drawFlag();
    this.drawCoins();
    this.drawPowers();
    this.drawEnemies();
    if (this.state !== "complete") this.drawPlayer();
    this.drawFires();
    this.drawCoinPops();
    this.drawParticles();
    this.drawPopups();
    ctx.restore();

    // rage vignette
    if (rage > 0.55 && this.state === "play") {
      const a = (rage - 0.55) * 0.5 * (0.7 + 0.3 * Math.sin(this.time * 6));
      const vg = ctx.createRadialGradient(VIEW_W / 2, VIEW_H / 2, VIEW_H * 0.35, VIEW_W / 2, VIEW_H / 2, VIEW_H * 0.85);
      vg.addColorStop(0, "rgba(255,0,0,0)");
      vg.addColorStop(1, `rgba(255,20,20,${a})`);
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, VIEW_W, VIEW_H);
    }
    // star flash border
    if (this.player.starT > 0 && this.state === "play") {
      ctx.save();
      ctx.globalAlpha = 0.5 + 0.5 * Math.sin(this.time * 12);
      ctx.strokeStyle = "#ffd700";
      ctx.lineWidth = 6;
      ctx.strokeRect(3, 3, VIEW_W - 6, VIEW_H - 6);
      ctx.restore();
    }
  }

  private drawHills(th: LevelData["theme"], mix: number) {
    const ctx = this.ctx;
    const baseY = GROUND_ROW * TILE;
    // far
    ctx.fillStyle = hexLerp(th.hillFar, "#0a0a20", mix * 0.55);
    for (const h of this.hillsFar) {
      const sx = h.x - this.camX * 0.25;
      if (sx < -200 || sx > VIEW_W + 200) continue;
      const w = 220 * h.s, hh = 130 * h.s;
      ctx.beginPath();
      ctx.moveTo(sx - w / 2, baseY);
      ctx.quadraticCurveTo(sx, baseY - hh * 1.4, sx + w / 2, baseY);
      ctx.fill();
      // snow cap for far hills
      ctx.fillStyle = "rgba(255,255,255,0.35)";
      ctx.beginPath();
      ctx.moveTo(sx - 22 * h.s, baseY - hh * 0.92);
      ctx.quadraticCurveTo(sx, baseY - hh * 1.4, sx + 22 * h.s, baseY - hh * 0.92);
      ctx.lineTo(sx + 12 * h.s, baseY - hh * 0.8);
      ctx.lineTo(sx, baseY - hh * 0.9);
      ctx.lineTo(sx - 12 * h.s, baseY - hh * 0.8);
      ctx.fill();
      ctx.fillStyle = hexLerp(th.hillFar, "#0a0a20", mix * 0.55);
    }
    // near
    ctx.fillStyle = hexLerp(th.hillNear, "#050512", mix * 0.5);
    for (const h of this.hillsNear) {
      const sx = h.x - this.camX * 0.5;
      if (sx < -200 || sx > VIEW_W + 200) continue;
      const w = 170 * h.s, hh = 95 * h.s;
      ctx.beginPath();
      ctx.moveTo(sx - w / 2, baseY);
      ctx.quadraticCurveTo(sx, baseY - hh * 1.4, sx + w / 2, baseY);
      ctx.fill();
    }
    // bushes
    ctx.fillStyle = hexLerp(th.bush, "#03130a", mix * 0.5);
    const spacing = 340;
    const off = -(this.camX * 0.7 % spacing);
    for (let x = off - spacing; x < VIEW_W + spacing; x += spacing) {
      const bx = x + ((Math.floor((x - off) / spacing) * 137) % 90);
      ctx.beginPath();
      ctx.arc(bx, baseY - 8, 26, 0, Math.PI * 2);
      ctx.arc(bx + 24, baseY - 4, 20, 0, Math.PI * 2);
      ctx.arc(bx - 24, baseY - 4, 20, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawClouds(th: LevelData["theme"], mix: number) {
    const ctx = this.ctx;
    ctx.fillStyle = hexLerp(th.cloud, "#3a466e", mix * 0.6);
    for (const c of this.clouds) {
      const sx = c.x - this.camX * 0.35;
      if (sx < -140 || sx > VIEW_W + 140) continue;
      const s = c.s;
      ctx.beginPath();
      ctx.arc(sx, c.y, 18 * s, 0, Math.PI * 2);
      ctx.arc(sx + 20 * s, c.y + 4 * s, 14 * s, 0, Math.PI * 2);
      ctx.arc(sx - 20 * s, c.y + 5 * s, 13 * s, 0, Math.PI * 2);
      ctx.arc(sx + 6 * s, c.y - 10 * s, 13 * s, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawTiles(th: LevelData["theme"]) {
    const ctx = this.ctx;
    const x0 = Math.max(0, Math.floor(this.camX / TILE) - 1);
    const x1 = Math.min(this.level.width - 1, Math.ceil((this.camX + VIEW_W) / TILE) + 1);
    // pits / lava under gaps
    for (let tx = x0; tx <= x1; tx++) {
      if (this.tiles[GROUND_ROW][tx] === T.EMPTY) {
        const sx = tx * TILE - this.camX;
        if (th.id === "volcano") {
          const lavaY = (GROUND_ROW + 1) * TILE - 6 + Math.sin(this.time * 4 + tx) * 3;
          ctx.fillStyle = "#3d0a0a";
          ctx.fillRect(sx, GROUND_ROW * TILE, TILE, VIEW_H - GROUND_ROW * TILE);
          ctx.fillStyle = "#ff5a00";
          ctx.fillRect(sx, lavaY, TILE, VIEW_H - lavaY);
          ctx.fillStyle = "#ffd700";
          for (let i = 0; i < 3; i++) {
            const bx = sx + ((tx * 13 + i * 11 + Math.floor(this.time * 8)) % 30);
            ctx.fillRect(bx, lavaY + 6 + (i * 7) % 14, 3, 3);
          }
        } else if (th.underground) {
          ctx.fillStyle = "#02020c";
          ctx.fillRect(sx, GROUND_ROW * TILE, TILE, VIEW_H - GROUND_ROW * TILE);
          ctx.fillStyle = "#123a5c";
          ctx.fillRect(sx, (GROUND_ROW + 1) * TILE + 8, TILE, 6);
        } else {
          ctx.fillStyle = "rgba(0,0,0,0.45)";
          ctx.fillRect(sx, GROUND_ROW * TILE, TILE, VIEW_H - GROUND_ROW * TILE);
        }
      }
    }
    for (let ty = 0; ty < ROWS; ty++) {
      for (let tx = x0; tx <= x1; tx++) {
        const t = this.tiles[ty][tx];
        if (t === T.EMPTY) continue;
        let dy = 0;
        const b = this.bounce.get(tx + "," + ty);
        if (b !== undefined) dy = -Math.sin((b / 0.18) * Math.PI) * 10;
        const sx = Math.round(tx * TILE - this.camX);
        const sy = Math.round(ty * TILE + dy);
        switch (t) {
          case T.GROUND: this.drawGround(ctx, sx, sy, th, ty); break;
          case T.BRICK: case T.STAR_BRICK: case T.ONEUP_BRICK: this.drawBrick(ctx, sx, sy); break;
          case T.QCOIN: case T.QMUSH: this.drawQuestion(ctx, sx, sy, t === T.QMUSH); break;
          case T.USED: this.drawUsed(ctx, sx, sy); break;
          case T.METAL: this.drawMetal(ctx, sx, sy); break;
          case T.PIPE_TL: this.drawPipe(ctx, sx, sy, 0, 0); break;
          case T.PIPE_TR: this.drawPipe(ctx, sx, sy, 1, 0); break;
          case T.PIPE_BL: this.drawPipe(ctx, sx, sy, 0, 1); break;
          case T.PIPE_BR: this.drawPipe(ctx, sx, sy, 1, 1); break;
          case T.SPIKE: this.drawSpike(ctx, sx, sy); break;
          case T.STONE: this.drawStone(ctx, sx, sy); break;
          case T.WOOD: this.drawWood(ctx, sx, sy); break;
          default: break;
        }
      }
    }
  }

  private drawGround(ctx: CanvasRenderingContext2D, x: number, y: number, th: LevelData["theme"], ty: number) {
    ctx.fillStyle = th.groundBase;
    ctx.fillRect(x, y, TILE, TILE);
    // speckles
    ctx.fillStyle = th.groundDark;
    ctx.fillRect(x + 6, y + 14, 5, 5);
    ctx.fillRect(x + 22, y + 22, 5, 5);
    ctx.fillRect(x + 14, y + 26, 4, 4);
    ctx.fillStyle = th.groundTop;
    ctx.fillRect(x + 4, y + 8, 4, 4);
    ctx.fillRect(x + 26, y + 12, 4, 4);
    // top grass strip
    if (ty === GROUND_ROW) {
      ctx.fillStyle = th.grass;
      ctx.fillRect(x, y, TILE, 10);
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.fillRect(x, y, TILE, 3);
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      for (let i = 0; i < TILE; i += 6) ctx.fillRect(x + i, y + 10, 3, 4);
    }
    ctx.fillStyle = "rgba(0,0,0,0.25)";
    ctx.fillRect(x, y + TILE - 3, TILE, 3);
  }

  private drawBrick(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y, TILE, TILE);
    ctx.fillStyle = "#e8792e";
    ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
    ctx.fillStyle = "#8f3d00";
    ctx.fillRect(x + 1, y + 11, TILE - 2, 2);
    ctx.fillRect(x + 1, y + 23, TILE - 2, 2);
    ctx.fillRect(x + 17, y + 1, 2, 11);
    ctx.fillRect(x + 8, y + 13, 2, 10);
    ctx.fillRect(x + 26, y + 13, 2, 10);
    ctx.fillRect(x + 17, y + 25, 2, 10);
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.fillRect(x + 1, y + 1, TILE - 2, 3);
  }

  private drawQuestion(ctx: CanvasRenderingContext2D, x: number, y: number, isMush: boolean) {
    const pulse = 0.5 + 0.5 * Math.sin(this.time * 5 + x * 0.05);
    const base = isMush ? "#ff7b3d" : "#f7b500";
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y, TILE, TILE);
    ctx.fillStyle = base;
    ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
    ctx.fillStyle = `rgba(255,255,255,${0.15 + pulse * 0.2})`;
    ctx.fillRect(x + 1, y + 1, TILE - 2, 6);
    ctx.fillStyle = "#7a4a00";
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + TILE - 6, y + 3, 3, 3);
    ctx.fillRect(x + 3, y + TILE - 6, 3, 3);
    ctx.fillRect(x + TILE - 6, y + TILE - 6, 3, 3);
    // ? mark (blink between light/dark)
    const c = Math.floor(this.time * 3 + x) % 3 === 0 ? "#fff3c4" : "#7a4a00";
    ctx.fillStyle = c;
    const qx = x + 13, qy = y + 6;
    ctx.fillRect(qx, qy, 10, 4);
    ctx.fillRect(qx + 8, qy + 4, 4, 6);
    ctx.fillRect(qx + 2, qy + 10, 6, 4);
    ctx.fillRect(qx + 2, qy + 16, 4, 2);
    ctx.fillRect(qx + 2, qy + 21, 4, 4);
  }

  private drawUsed(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y, TILE, TILE);
    ctx.fillStyle = "#8a5a2b";
    ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
    ctx.fillStyle = "#5c3a15";
    ctx.fillRect(x + 3, y + 3, 3, 3);
    ctx.fillRect(x + TILE - 6, y + 3, 3, 3);
    ctx.fillRect(x + 3, y + TILE - 6, 3, 3);
    ctx.fillRect(x + TILE - 6, y + TILE - 6, 3, 3);
  }

  private drawMetal(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y, TILE, TILE);
    ctx.fillStyle = "#9aa3b2";
    ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
    ctx.fillStyle = "#d7dde8";
    ctx.fillRect(x + 3, y + 3, TILE - 6, 5);
    ctx.fillStyle = "#5c6470";
    ctx.fillRect(x + 3, y + TILE - 8, TILE - 6, 5);
    ctx.strokeStyle = "#4a515c";
    ctx.lineWidth = 2;
    ctx.strokeRect(x + 8, y + 8, TILE - 16, TILE - 16);
  }

  private drawStone(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y, TILE, TILE);
    ctx.fillStyle = "#c98f4e";
    ctx.fillRect(x + 1, y + 1, TILE - 2, TILE - 2);
    ctx.fillStyle = "#8f5a1e";
    ctx.fillRect(x + 1, y + TILE - 7, TILE - 2, 6);
    ctx.fillStyle = "#f7d9a0";
    ctx.fillRect(x + 1, y + 1, TILE - 2, 4);
    ctx.fillStyle = "#8f5a1e";
    ctx.fillRect(x + 8, y + 10, 3, 12);
    ctx.fillRect(x + 24, y + 10, 3, 12);
  }

  private drawWood(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x, y - 2, TILE, 16);
    ctx.fillStyle = "#c97b2e";
    ctx.fillRect(x + 1, y - 1, TILE - 2, 13);
    ctx.fillStyle = "#8f4a1a";
    ctx.fillRect(x + 1, y + 7, TILE - 2, 3);
    ctx.fillStyle = "#f7d9a0";
    ctx.fillRect(x + 1, y - 1, TILE - 2, 3);
    ctx.fillStyle = "#5c2d08";
    ctx.fillRect(x + 4, y + 1, 2, 8);
    ctx.fillRect(x + TILE - 6, y + 1, 2, 8);
  }

  private drawPipe(ctx: CanvasRenderingContext2D, x: number, y: number, px: number, py: number) {
    const rim = py === 0;
    // rim is wider than the body, like the classics
    const x0 = px === 0 ? (rim ? x - 4 : x + 3) : x;
    const ww = px === 0 ? (rim ? TILE + 4 : TILE - 3) : rim ? TILE + 4 : TILE - 3;
    ctx.fillStyle = "#063d0c";
    ctx.fillRect(x0 - 1, y, ww + 2, TILE + 1);
    const start = (px === 0 ? x : x - TILE) + (rim ? -4 : 3);
    const grad = ctx.createLinearGradient(start, 0, start + TILE * 2 + (rim ? 8 : -6), 0);
    grad.addColorStop(0, "#0d4215");
    grad.addColorStop(0.16, "#2b9e3d");
    grad.addColorStop(0.34, "#7bf78f");
    grad.addColorStop(0.5, "#3fd44f");
    grad.addColorStop(0.78, "#1d7a2b");
    grad.addColorStop(1, "#0d4215");
    ctx.fillStyle = grad;
    ctx.fillRect(x0, y + 1, ww, TILE - 1);
    if (rim) {
      ctx.fillStyle = "rgba(255,255,255,0.55)";
      ctx.fillRect(x0, y + 1, ww, 5);
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x0, y + TILE - 5, ww, 4);
    }
  }

  private drawSpike(ctx: CanvasRenderingContext2D, x: number, y: number) {
    ctx.fillStyle = "#1a1a22";
    ctx.fillRect(x, y + TILE - 10, TILE, 10);
    ctx.fillStyle = "#c9d1e0";
    for (let i = 0; i < 4; i++) {
      const bx = x + 2 + i * 9;
      ctx.beginPath();
      ctx.moveTo(bx, y + TILE - 8);
      ctx.lineTo(bx + 4.5, y + 8);
      ctx.lineTo(bx + 9, y + TILE - 8);
      ctx.fill();
    }
    ctx.fillStyle = "#ffffff";
    for (let i = 0; i < 4; i++) ctx.fillRect(x + 4 + i * 9, y + 14, 2, 8);
  }

  private drawCastle() {
    const ctx = this.ctx;
    const bx = this.level.castleCol * TILE - this.camX;
    if (bx < -300 || bx > VIEW_W + 100) return;
    const baseY = GROUND_ROW * TILE;
    const W = TILE * 5, H = TILE * 4;
    const x = bx - TILE;
    const y = baseY - H;
    // shadow
    ctx.fillStyle = "rgba(0,0,0,0.3)";
    ctx.fillRect(x + 6, baseY - 4, W, 6);
    // body
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 2, y - 2, W + 4, H + 2);
    ctx.fillStyle = "#c9562b";
    ctx.fillRect(x, y, W, H);
    // bricks
    ctx.fillStyle = "#8f3415";
    for (let r = 0; r < H; r += 12) ctx.fillRect(x, y + r, W, 2);
    // battlements
    ctx.fillStyle = "#c9562b";
    ctx.strokeStyle = "#0a0a0a";
    for (let i = 0; i < 5; i++) {
      const cx = x + i * (W / 5);
      ctx.fillRect(cx, y - 18, W / 5 - 6, 20);
      ctx.strokeRect(cx, y - 18, W / 5 - 6, 20);
    }
    // tower
    const tx = x + W / 2 - TILE;
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(tx - 2, y - TILE * 2 - 2, TILE * 2 + 4, TILE * 2 + 2);
    ctx.fillStyle = "#c9562b";
    ctx.fillRect(tx, y - TILE * 2, TILE * 2, TILE * 2);
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = "#c9562b";
      ctx.fillRect(tx + i * 24, y - TILE * 2 - 14, 18, 16);
      ctx.strokeStyle = "#0a0a0a";
      ctx.strokeRect(tx + i * 24, y - TILE * 2 - 14, 18, 16);
    }
    // door
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x + W / 2 - 16, baseY - 52, 32, 52);
    ctx.fillStyle = "#3d1a08";
    ctx.fillRect(x + W / 2 - 13, baseY - 49, 26, 49);
    // windows
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x + 14, y + 40, 18, 24);
    ctx.fillRect(x + W - 32, y + 40, 18, 24);
    ctx.fillRect(tx + TILE - 9, y - TILE * 2 + 30, 18, 22);
    // flag on tower
    ctx.fillStyle = "#e8e8e8";
    ctx.fillRect(tx + TILE - 2, y - TILE * 2 - 44, 4, 32);
    const wave = Math.sin(this.time * 6) * 3;
    ctx.fillStyle = "#22b14c";
    ctx.beginPath();
    ctx.moveTo(tx + TILE + 2, y - TILE * 2 - 44);
    ctx.lineTo(tx + TILE + 30, y - TILE * 2 - 36 + wave);
    ctx.lineTo(tx + TILE + 2, y - TILE * 2 - 28);
    ctx.fill();
  }

  private drawCheckpoint() {
    const ctx = this.ctx;
    const x = this.level.checkpointCol * TILE - this.camX + TILE / 2;
    if (x < -40 || x > VIEW_W + 40) return;
    const topY = (GROUND_ROW - 5) * TILE;
    const botY = GROUND_ROW * TILE;
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 3, topY, 6, botY - topY);
    ctx.fillStyle = "#d7dde8";
    ctx.fillRect(x - 2, topY, 3, botY - topY);
    ctx.fillStyle = "#ffd700";
    ctx.beginPath(); ctx.arc(x, topY - 4, 6, 0, Math.PI * 2); ctx.fill();
    const wave = Math.sin(this.time * 5) * 2;
    ctx.fillStyle = this.checkpointOn ? "#7bff00" : "#8a8f9e";
    ctx.beginPath();
    ctx.moveTo(x + 3, topY + 4);
    ctx.lineTo(x + 30, topY + 12 + wave);
    ctx.lineTo(x + 3, topY + 22);
    ctx.fill();
  }

  private drawFlag() {
    const ctx = this.ctx;
    const x = this.level.flagCol * TILE - this.camX + TILE / 2;
    if (x < -60 || x > VIEW_W + 60) return;
    const topY = 3 * TILE;
    const botY = GROUND_ROW * TILE;
    // base
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 14, botY - 12, 28, 12);
    ctx.fillStyle = "#5c6470";
    ctx.fillRect(x - 12, botY - 10, 24, 8);
    // pole
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 3, topY, 6, botY - topY);
    ctx.fillStyle = "#22b14c";
    ctx.fillRect(x - 2, topY, 3, botY - topY);
    // ball
    ctx.fillStyle = "#ffd700";
    ctx.beginPath(); ctx.arc(x, topY - 6, 8, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#fff3c4";
    ctx.beginPath(); ctx.arc(x - 2, topY - 8, 3, 0, Math.PI * 2); ctx.fill();
    // flag triangle (slides)
    const fy = this.state === "play" ? 4 * TILE : this.flagY;
    const wave = Math.sin(this.time * 6) * 3;
    ctx.fillStyle = "#22b14c";
    ctx.strokeStyle = "#0a0a0a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - 3, fy);
    ctx.lineTo(x - 52, fy + 18 + wave);
    ctx.lineTo(x - 3, fy + 38);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // skull emblem
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 34, fy + 14, 10, 10);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 32, fy + 16, 3, 3);
    ctx.fillRect(x - 27, fy + 16, 3, 3);
  }

  private drawCoins() {
    const ctx = this.ctx;
    for (const c of this.coins) {
      if (c.taken) continue;
      const sx = c.x - this.camX;
      if (sx < -30 || sx > VIEW_W + 30) continue;
      const bobY = Math.sin(this.time * 3 + c.bob) * 3;
      const spin = Math.abs(Math.cos(this.time * 5 + c.bob));
      const w = 8 + spin * 18;
      ctx.save();
      ctx.translate(sx, c.y + bobY);
      // glow
      ctx.fillStyle = "rgba(255,215,0,0.25)";
      ctx.beginPath(); ctx.arc(0, 0, 20, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#0a0a0a";
      ctx.beginPath(); ctx.ellipse(0, 0, w / 2 + 2, 15, 0, 0, Math.PI * 2); ctx.fill();
      const g = ctx.createLinearGradient(-w / 2, 0, w / 2, 0);
      g.addColorStop(0, "#9c7a00");
      g.addColorStop(0.5, "#ffd700");
      g.addColorStop(1, "#9c7a00");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(0, 0, w / 2, 13, 0, 0, Math.PI * 2); ctx.fill();
      if (spin > 0.4) {
        ctx.fillStyle = "#fff3c4";
        ctx.fillRect(-3, -8, 4, 16);
      }
      ctx.restore();
    }
  }

  private drawPowers() {
    const ctx = this.ctx;
    for (const m of this.powers) {
      const sx = m.x - this.camX;
      if (m.kind === "mush" || m.kind === "oneup") {
        const cap = m.kind === "mush" ? "#e52521" : "#22b14c";
        const dark = m.kind === "mush" ? "#8f1414" : "#0f6b2c";
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(sx - 1, m.y - 1, m.w + 2, m.h + 2);
        // stem
        ctx.fillStyle = "#ffe0c2";
        ctx.fillRect(sx + 8, m.y + 14, 14, 15);
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(sx + 10, m.y + 18, 3, 4);
        ctx.fillRect(sx + 17, m.y + 18, 3, 4);
        // cap
        ctx.fillStyle = cap;
        ctx.beginPath();
        ctx.ellipse(sx + m.w / 2, m.y + 13, 16, 12, 0, Math.PI, 0);
        ctx.fill();
        ctx.fillRect(sx - 1, m.y + 12, m.w + 2, 4);
        ctx.fillStyle = dark;
        ctx.fillRect(sx - 1, m.y + 14, m.w + 2, 2);
        // spots
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(sx + 5, m.y + 4, 6, 6);
        ctx.fillRect(sx + 19, m.y + 4, 6, 6);
        ctx.fillRect(sx + 12, m.y + 9, 6, 5);
      } else if (m.kind === "flower") {
        const cx = sx + m.w / 2, cy = m.y + 12;
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(sx - 1, m.y - 1, m.w + 2, m.h + 2);
        // stem
        ctx.fillStyle = "#22b14c";
        ctx.fillRect(cx - 3, cy, 6, 16);
        ctx.fillStyle = "#22b14c";
        ctx.beginPath(); ctx.ellipse(cx - 8, cy + 10, 7, 4, -0.5, 0, Math.PI * 2); ctx.fill();
        // petals
        const cols = ["#ff7b00", "#ffd700"];
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2 + this.time * 2;
          ctx.fillStyle = cols[i % 2];
          ctx.beginPath();
          ctx.arc(cx + Math.cos(a) * 9, cy + Math.sin(a) * 7, 6, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.fillStyle = "#ffffff";
        ctx.beginPath(); ctx.arc(cx, cy, 5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(cx - 2, cy - 2, 2, 2);
        ctx.fillRect(cx + 1, cy - 2, 2, 2);
      } else {
        // star
        const cx = sx + m.w / 2, cy = m.y + m.h / 2;
        const flash = Math.floor(this.time * 10) % 2 === 0;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(Math.sin(this.time * 4) * 0.2);
        ctx.fillStyle = "#0a0a0a";
        this.starPath(ctx, 0, 0, 18);
        ctx.fill();
        ctx.fillStyle = flash ? "#ffd700" : "#ff9a3d";
        this.starPath(ctx, 0, 0, 15);
        ctx.fill();
        ctx.fillStyle = "#0a0a0a";
        ctx.fillRect(-5, -3, 3, 5);
        ctx.fillRect(2, -3, 3, 5);
        ctx.restore();
      }
    }
  }

  private starPath(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i / 10) * Math.PI * 2;
      const rr = i % 2 === 0 ? r : r * 0.45;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
  }

  private drawEnemies() {
    const ctx = this.ctx;
    for (const e of this.enemies) {
      const sx = Math.round(e.x - this.camX);
      if (sx < -60 || sx > VIEW_W + 60) continue;
      if (e.state === "dead") {
        ctx.save();
        ctx.globalAlpha = clamp(e.deadT * 2, 0, 1);
        ctx.translate(sx + e.w / 2, e.y + e.h / 2);
        ctx.scale(1, 0.4);
        ctx.fillStyle = "#3d2314";
        ctx.fillRect(-e.w / 2, -e.h / 2, e.w, e.h);
        ctx.restore();
        continue;
      }
      // flash before shell wakes
      if (e.state === "shell" && e.stateT < 2 && Math.floor(this.time * 8) % 2 === 0) {
        ctx.save();
        ctx.globalAlpha = 0.5;
      }
      if (e.type === "walker") this.drawWalker(ctx, sx, e.y, e);
      else if (e.type === "turtle") this.drawTurtle(ctx, sx, e.y, e);
      else if (e.type === "spiky") this.drawSpiky(ctx, sx, e.y, e);
      else this.drawFlyer(ctx, sx, e.y, e);
      if (e.state === "shell" && e.stateT < 2 && Math.floor(this.time * 8) % 2 === 0) ctx.restore();
      // rage eyes glow
      if (this.rage01() > 0.6 && e.state !== "shell") {
        ctx.fillStyle = `rgba(255,30,30,${0.4 + 0.4 * Math.sin(this.time * 8)})`;
        ctx.fillRect(sx + (e.dir > 0 ? e.w - 12 : 6), e.y + 8, 6, 4);
      }
    }
  }

  private drawWalker(ctx: CanvasRenderingContext2D, x: number, y: number, e: Enemy) {
    const step = Math.floor(e.animT * 8) % 2;
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 1, y - 1, e.w + 2, e.h + 2);
    // body
    ctx.fillStyle = "#8a4a1a";
    ctx.fillRect(x, y, e.w, e.h - 6);
    ctx.fillStyle = "#c97b2e";
    ctx.beginPath();
    ctx.ellipse(x + e.w / 2, y + 10, e.w / 2 - 2, 10, 0, Math.PI, 0);
    ctx.fill();
    // angry eyes
    ctx.fillStyle = "#ffffff";
    const ex = e.dir > 0 ? 4 : -4;
    ctx.fillRect(x + 6 + ex, y + 10, 7, 9);
    ctx.fillRect(x + 17 + ex, y + 10, 7, 9);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x + 8 + ex, y + 13, 4, 5);
    ctx.fillRect(x + 19 + ex, y + 13, 4, 5);
    // brows
    ctx.fillStyle = "#3d1a08";
    ctx.fillRect(x + 5 + ex, y + 7, 9, 4);
    ctx.fillRect(x + 16 + ex, y + 7, 9, 4);
    // feet
    ctx.fillStyle = "#3d1a08";
    const f1 = step === 0 ? -3 : 3;
    ctx.fillRect(x + 1 + f1, y + e.h - 6, 12, 6);
    ctx.fillRect(x + 17 - f1, y + e.h - 6, 12, 6);
  }

  private drawTurtle(ctx: CanvasRenderingContext2D, x: number, y: number, e: Enemy) {
    if (e.state === "shell" || e.state === "shellmove") {
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(x - 1, y - 1, e.w + 2, 24);
      ctx.fillStyle = "#22b14c";
      ctx.fillRect(x, y, e.w, 22);
      ctx.fillStyle = "#7bf78f";
      ctx.fillRect(x + 2, y + 2, e.w - 4, 6);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(x + 2, y + 14, e.w - 4, 6);
      ctx.fillStyle = "#0f6b2c";
      for (let i = 0; i < 3; i++) ctx.fillRect(x + 5 + i * 8, y + 4, 2, 12);
    } else {
      const step = Math.floor(e.animT * 8) % 2;
      // head
      const hx = e.dir > 0 ? x + e.w - 8 : x - 2;
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(hx - 1, y - 1, 12, 14);
      ctx.fillStyle = "#ffe0a3";
      ctx.fillRect(hx, y, 10, 12);
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(hx + (e.dir > 0 ? 5 : 2), y + 4, 3, 4);
      // shell
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(x - 1, y + 9, e.w + 2, e.h - 9);
      ctx.fillStyle = "#22b14c";
      ctx.fillRect(x, y + 10, e.w, e.h - 12);
      ctx.fillStyle = "#7bf78f";
      ctx.fillRect(x + 2, y + 12, e.w - 4, 6);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(x + 2, y + e.h - 10, e.w - 4, 6);
      ctx.fillStyle = "#0f6b2c";
      for (let i = 0; i < 3; i++) ctx.fillRect(x + 5 + i * 8, y + 13, 2, 10);
      // feet
      ctx.fillStyle = "#c98f4e";
      const f1 = step === 0 ? -3 : 3;
      ctx.fillRect(x + 1 + f1, y + e.h - 5, 10, 5);
      ctx.fillRect(x + e.w - 11 - f1, y + e.h - 5, 10, 5);
    }
  }

  private drawSpiky(ctx: CanvasRenderingContext2D, x: number, y: number, e: Enemy) {
    const step = Math.floor(e.animT * 8) % 2;
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 1, y - 1, e.w + 2, e.h + 2);
    ctx.fillStyle = "#c92a2a";
    ctx.beginPath();
    ctx.ellipse(x + e.w / 2, y + e.h - 8, e.w / 2, 14, 0, Math.PI, 0);
    ctx.fill();
    ctx.fillRect(x, y + e.h - 10, e.w, 4);
    // spikes
    ctx.fillStyle = "#ffffff";
    for (let i = 0; i < 4; i++) {
      const bx = x + 2 + i * 7;
      ctx.beginPath();
      ctx.moveTo(bx, y + 12);
      ctx.lineTo(bx + 3.5, y + 1);
      ctx.lineTo(bx + 7, y + 12);
      ctx.fill();
    }
    // eyes
    ctx.fillStyle = "#ffffff";
    const ex = e.dir > 0 ? 3 : -3;
    ctx.fillRect(x + 8 + ex, y + 14, 6, 7);
    ctx.fillRect(x + 17 + ex, y + 14, 6, 7);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x + 10 + ex, y + 16, 3, 4);
    ctx.fillRect(x + 19 + ex, y + 16, 3, 4);
    // feet
    ctx.fillStyle = "#5c0d0d";
    const f1 = step === 0 ? -3 : 3;
    ctx.fillRect(x + 1 + f1, y + e.h - 5, 12, 5);
    ctx.fillRect(x + 17 - f1, y + e.h - 5, 12, 5);
  }

  private drawFlyer(ctx: CanvasRenderingContext2D, x: number, y: number, e: Enemy) {
    const flap = Math.sin(e.wingT * 10) > 0;
    // wings
    ctx.fillStyle = "#0a0a0a";
    if (flap) {
      ctx.fillRect(x - 8, y - 6, 14, 14);
      ctx.fillRect(x + e.w - 6, y - 6, 14, 14);
      ctx.fillStyle = "#7b2bff";
      ctx.fillRect(x - 7, y - 5, 12, 12);
      ctx.fillRect(x + e.w - 5, y - 5, 12, 12);
    } else {
      ctx.fillRect(x - 8, y + 8, 14, 12);
      ctx.fillRect(x + e.w - 6, y + 8, 14, 12);
      ctx.fillStyle = "#5b1ec4";
      ctx.fillRect(x - 7, y + 9, 12, 10);
      ctx.fillRect(x + e.w - 5, y + 9, 12, 10);
    }
    // body
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x - 1, y - 1, e.w + 2, e.h + 2);
    ctx.fillStyle = "#3d1a8f";
    ctx.fillRect(x, y, e.w, e.h);
    ctx.fillStyle = "#7b2bff";
    ctx.beginPath();
    ctx.ellipse(x + e.w / 2, y + 8, e.w / 2 - 3, 7, 0, Math.PI, 0);
    ctx.fill();
    // eyes
    ctx.fillStyle = "#ffd700";
    const ex = e.dir > 0 ? 3 : -3;
    ctx.fillRect(x + 7 + ex, y + 10, 6, 7);
    ctx.fillRect(x + 17 + ex, y + 10, 6, 7);
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(x + 9 + ex, y + 12, 3, 4);
    ctx.fillRect(x + 19 + ex, y + 12, 3, 4);
    // beak
    ctx.fillStyle = "#ff9a3d";
    ctx.fillRect(x + e.w / 2 - 3, y + 18, 6, 5);
  }

  private drawPlayer() {
    const ctx = this.ctx;
    const p = this.player;
    if (p.invT > 0 && this.state === "play" && Math.floor(this.time * 12) % 2 === 0 && p.starT <= 0) return; // blink
    const skin = this.opts.skin.colors;
    const sx = Math.round(p.x - this.camX);
    const sy = Math.round(p.y);
    const squash = 1 + p.squash;
    const w = p.w, h = p.h;

    ctx.save();
    ctx.translate(sx + w / 2, sy + h);
    ctx.scale(p.face, squash > 0 ? 1 / Math.sqrt(squash) : 1);
    ctx.translate(-w / 2, -h);

    const big = p.big;
    const u = big ? h / 26 : h / 16; // unit
    void u;
    const shirt = p.fire ? "#ffffff" : skin.shirt;
    const hat = p.fire ? "#ffffff" : skin.hat;
    const hatDark = p.fire ? "#e52521" : skin.hatDark;
    const overalls = p.fire ? "#e52521" : skin.overalls;

    const runPhase = Math.floor(p.animT * 6) % 4;
    const legSwing = !p.onGround ? 0 : runPhase === 1 ? 3 : runPhase === 3 ? -3 : 0;
    const armSwing = !p.onGround ? -4 : runPhase === 1 ? -3 : runPhase === 3 ? 3 : 0;
    const jumpPose = !p.onGround;

    // star rainbow tint
    if (p.starT > 0) {
      const cols = ["#ffd700", "#00e5ff", "#ff5da2", "#7bff00"];
      ctx.fillStyle = cols[Math.floor(this.time * 12) % 4];
      ctx.globalAlpha = 0.35;
      ctx.fillRect(-3, -3, w + 6, h + 6);
      ctx.globalAlpha = 1;
    }
    if (this.opts.skin.glow) {
      ctx.shadowColor = this.opts.skin.glow;
      ctx.shadowBlur = 12;
    }

    const X = (v: number) => v; // facing handled by scale
    void X;
    if (!big) {
      // SMALL — 24x32
      // shoes
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(1 + legSwing, 26, 10, 7);
      ctx.fillRect(12 - legSwing, 26, 10, 7);
      ctx.fillStyle = skin.shoes;
      ctx.fillRect(2 + legSwing, 27, 8, 5);
      ctx.fillRect(13 - legSwing, 27, 8, 5);
      // legs (overalls)
      ctx.fillStyle = overalls;
      ctx.fillRect(3 + legSwing, 21, 7, 6);
      ctx.fillRect(14 - legSwing, 21, 7, 6);
      // body
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(2, 12, 20, 11);
      ctx.fillStyle = shirt;
      ctx.fillRect(3, 13, 18, 9);
      // overall straps + buttons
      ctx.fillStyle = overalls;
      ctx.fillRect(6, 13, 5, 9);
      ctx.fillRect(13, 13, 5, 9);
      ctx.fillStyle = "#ffd700";
      ctx.fillRect(6, 16, 2, 2);
      ctx.fillRect(16, 16, 2, 2);
      // arms
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(0, 14 + armSwing, 4, 8);
      ctx.fillRect(20, 14 - armSwing, 4, 8);
      ctx.fillStyle = skin.glove;
      ctx.fillRect(0, 17 + armSwing, 4, 5);
      ctx.fillRect(20, 17 - armSwing, 4, 5);
      // head
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(4, 3, 17, 10);
      ctx.fillStyle = skin.skin;
      ctx.fillRect(5, 4, 15, 8);
      // nose + eye
      ctx.fillStyle = skin.skin;
      ctx.fillRect(20, 7, 4, 4);
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(13, 6, 3, 4);
      // hat
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(2, -1, 21, 6);
      ctx.fillStyle = hat;
      ctx.fillRect(3, 0, 19, 4);
      ctx.fillStyle = hatDark;
      ctx.fillRect(3, 3, 19, 1);
      // hat emblem
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(10, 0, 5, 4);
      ctx.fillStyle = hatDark;
      ctx.fillRect(11, 1, 3, 2);
      if (jumpPose) {
        // arms up handled by armSwing already
      }
    } else {
      // BIG — 26x52
      // shoes
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(1 + legSwing, 44, 11, 9);
      ctx.fillRect(14 - legSwing, 44, 11, 9);
      ctx.fillStyle = skin.shoes;
      ctx.fillRect(2 + legSwing, 45, 9, 7);
      ctx.fillRect(15 - legSwing, 45, 9, 7);
      ctx.fillStyle = "rgba(255,255,255,0.3)";
      ctx.fillRect(2 + legSwing, 45, 9, 2);
      ctx.fillRect(15 - legSwing, 45, 9, 2);
      // legs
      ctx.fillStyle = overalls;
      ctx.fillRect(3 + legSwing, 33, 8, 12);
      ctx.fillRect(15 - legSwing, 33, 8, 12);
      // torso
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(2, 18, 22, 17);
      ctx.fillStyle = overalls;
      ctx.fillRect(3, 19, 20, 15);
      ctx.fillStyle = shirt;
      ctx.fillRect(3, 19, 5, 15);
      ctx.fillRect(18, 19, 5, 15);
      // buttons
      ctx.fillStyle = "#ffd700";
      ctx.fillRect(8, 23, 3, 3);
      ctx.fillRect(15, 23, 3, 3);
      // arms
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(-1, 20 + armSwing, 5, 11);
      ctx.fillRect(22, 20 - armSwing, 5, 11);
      ctx.fillStyle = shirt;
      ctx.fillRect(0, 21 + armSwing, 4, 6);
      ctx.fillRect(22, 21 - armSwing, 4, 6);
      ctx.fillStyle = skin.glove;
      ctx.fillRect(0, 26 + armSwing, 4, 6);
      ctx.fillRect(22, 26 - armSwing, 4, 6);
      // head
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(4, 7, 19, 12);
      ctx.fillStyle = skin.skin;
      ctx.fillRect(5, 8, 17, 10);
      // nose
      ctx.fillStyle = skin.skin;
      ctx.fillRect(22, 11, 4, 5);
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(14, 10, 4, 5);
      // mustache!
      ctx.fillStyle = "#3d1a08";
      ctx.fillRect(12, 15, 11, 3);
      // hat
      ctx.fillStyle = "#0a0a0a";
      ctx.fillRect(2, 1, 23, 8);
      ctx.fillStyle = hat;
      ctx.fillRect(3, 2, 21, 6);
      ctx.fillStyle = hatDark;
      ctx.fillRect(3, 6, 21, 2);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(10, 2, 7, 6);
      ctx.fillStyle = hatDark;
      ctx.fillRect(12, 3, 4, 4);
    }
    ctx.restore();
  }

  private drawFires() {
    const ctx = this.ctx;
    for (const f of this.fires) {
      const sx = f.x - this.camX;
      const flick = Math.floor(this.time * 20) % 2;
      ctx.fillStyle = "#0a0a0a";
      ctx.beginPath(); ctx.arc(sx + f.w / 2, f.y + f.h / 2, 9, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = flick ? "#ff7b00" : "#ffd700";
      ctx.beginPath(); ctx.arc(sx + f.w / 2, f.y + f.h / 2, 7, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.arc(sx + f.w / 2, f.y + f.h / 2, 3, 0, Math.PI * 2); ctx.fill();
    }
  }

  private drawCoinPops() {
    const ctx = this.ctx;
    for (const c of this.coinPops) {
      const sx = c.x - this.camX;
      const spin = Math.abs(Math.cos(c.t * 18));
      const w = 8 + spin * 18;
      ctx.fillStyle = "#0a0a0a";
      ctx.beginPath(); ctx.ellipse(sx, c.y, w / 2 + 2, 15, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#ffd700";
      ctx.beginPath(); ctx.ellipse(sx, c.y, w / 2, 13, 0, 0, Math.PI * 2); ctx.fill();
    }
  }

  private drawParticles() {
    const ctx = this.ctx;
    for (const p of this.particles) {
      const sx = p.x - this.camX;
      ctx.globalAlpha = clamp(p.life / p.maxLife, 0, 1);
      ctx.fillStyle = p.color;
      if (p.shape === "circle") {
        ctx.beginPath(); ctx.arc(sx, p.y, p.size / 2, 0, Math.PI * 2); ctx.fill();
      } else ctx.fillRect(sx, p.y, p.size, p.size);
    }
    ctx.globalAlpha = 1;
  }

  private drawPopups() {
    const ctx = this.ctx;
    ctx.save();
    ctx.font = '10px "Press Start 2P", monospace';
    ctx.textAlign = "center";
    for (const p of this.popups) {
      const sx = p.x - this.camX;
      ctx.globalAlpha = clamp(p.life * 1.5, 0, 1);
      ctx.fillStyle = "#000000";
      ctx.fillText(p.text, sx + 2, p.y + 2);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, sx, p.y);
    }
    ctx.restore();
  }
}
